create function topic() returns text
    stable
    language sql
as
$$
select nullif(current_setting('realtime.topic', true), '')::text;
$$;

alter function topic() owner to supabase_realtime_admin;

grant execute on function topic() to postgres;

grant execute on function topic() to dashboard_user;


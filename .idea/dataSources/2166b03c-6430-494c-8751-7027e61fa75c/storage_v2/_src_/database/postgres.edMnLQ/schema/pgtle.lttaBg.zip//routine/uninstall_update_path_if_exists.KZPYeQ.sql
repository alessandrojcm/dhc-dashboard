create function uninstall_update_path_if_exists(extname text, fromvers text, tovers text) returns boolean
    strict
    SET search_path = pgtle
    language plpgsql
as
$$
BEGIN
  PERFORM pgtle.uninstall_update_path(extname, fromvers, tovers);
  RETURN TRUE;
EXCEPTION
  WHEN no_data_found THEN
    RETURN FALSE;
END;
$$;

alter function uninstall_update_path_if_exists(text, text, text) owner to supabase_admin;

grant execute on function uninstall_update_path_if_exists(text, text, text) to pgtle_admin;


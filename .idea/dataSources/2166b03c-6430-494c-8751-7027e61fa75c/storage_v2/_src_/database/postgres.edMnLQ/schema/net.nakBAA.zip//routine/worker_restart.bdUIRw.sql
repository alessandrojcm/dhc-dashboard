create function worker_restart() returns boolean
    security definer
    language sql
as
$$
  select pg_reload_conf();
  select pg_terminate_backend(pid)
  from pg_stat_activity
  where backend_type ilike '%pg_net%';
$$;

alter function worker_restart() owner to supabase_admin;


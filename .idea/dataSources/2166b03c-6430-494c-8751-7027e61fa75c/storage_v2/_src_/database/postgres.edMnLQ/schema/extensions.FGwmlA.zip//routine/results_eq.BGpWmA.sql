create function results_eq(refcursor, text) returns text
    language sql
as
$$
    SELECT results_eq( $1, $2, NULL::text );
$$;

alter function results_eq(refcursor, text) owner to supabase_admin;

grant execute on function results_eq(refcursor, text) to postgres with grant option;


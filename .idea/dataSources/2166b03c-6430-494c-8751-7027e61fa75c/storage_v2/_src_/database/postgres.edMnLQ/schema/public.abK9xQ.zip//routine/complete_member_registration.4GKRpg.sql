create function complete_member_registration(p_user_profile_id uuid, p_next_of_kin_name text, p_next_of_kin_phone text, p_preferred_weapon preferred_weapon, p_additional_data jsonb DEFAULT '{}'::jsonb) returns uuid
    security definer
    SET search_path = ""
    language plpgsql
as
$$
DECLARE
    v_member_id UUID;
    v_user_id   UUID;
BEGIN
    -- Get user ID
    SELECT supabase_user_id
    INTO v_user_id
    FROM public.user_profiles
    WHERE id = p_user_profile_id;

    IF v_user_id IS NULL THEN
        RAISE EXCEPTION 'User profile not found';
    END IF;

    -- Create member profile
    INSERT INTO public.member_profiles (id,
                                        user_profile_id,
                                        next_of_kin_name,
                                        next_of_kin_phone,
                                        preferred_weapon,
                                        additional_data)
    VALUES (v_user_id,
            p_user_profile_id,
            p_next_of_kin_name,
            p_next_of_kin_phone,
            p_preferred_weapon,
            p_additional_data)
    RETURNING id INTO v_member_id;

    -- Add member role
    INSERT INTO public.user_roles (user_id, role)
    VALUES (v_user_id, 'member'::public.role_type);

    RETURN v_member_id;
END;
$$;

alter function complete_member_registration(uuid, text, text, preferred_weapon, jsonb) owner to postgres;

grant execute on function complete_member_registration(uuid, text, text, preferred_weapon, jsonb) to anon;

grant execute on function complete_member_registration(uuid, text, text, preferred_weapon, jsonb) to authenticated;

grant execute on function complete_member_registration(uuid, text, text, preferred_weapon, jsonb) to service_role;


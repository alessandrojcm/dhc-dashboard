create function hasnt_view(name, name, text) returns text
    language sql
as
$$
    SELECT ok( NOT _rexists( 'v', $1, $2 ), $3 );
$$;

alter function hasnt_view(name, name, text) owner to supabase_admin;

grant execute on function hasnt_view(name, name, text) to postgres with grant option;


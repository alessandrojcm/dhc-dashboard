create function key_encrypt_secret_raw_key() returns trigger
    language plpgsql
as
$$
		BEGIN
		        new.raw_key = CASE WHEN new.raw_key IS NULL THEN NULL ELSE
			CASE WHEN new.parent_key IS NULL THEN NULL ELSE
					pgsodium.crypto_aead_det_encrypt(new.raw_key::bytea, pg_catalog.convert_to((new.id::text || new.associated_data::text)::text, 'utf8'),
			new.parent_key::uuid,
			new.raw_key_nonce
		  ) END END;
		RETURN new;
		END;
		$$;

alter function key_encrypt_secret_raw_key() owner to supabase_admin;


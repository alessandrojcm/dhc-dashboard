create function _get_note(integer) returns text
    strict
    language plpgsql
as
$$
DECLARE
    ret text;
BEGIN
    EXECUTE 'SELECT note FROM __tcache__ WHERE id = ' || $1 || ' LIMIT 1' INTO ret;
    RETURN ret;
END;
$$;

alter function _get_note(integer) owner to supabase_admin;

grant execute on function _get_note(integer) to postgres with grant option;


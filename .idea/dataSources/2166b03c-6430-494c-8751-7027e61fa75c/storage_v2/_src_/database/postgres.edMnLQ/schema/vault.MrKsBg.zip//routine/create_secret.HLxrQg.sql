create function create_secret(new_secret text, new_name text DEFAULT NULL::text, new_description text DEFAULT ''::text, new_key_id uuid DEFAULT NULL::uuid) returns uuid
    language sql
as
$$
    INSERT INTO vault.secrets (secret, name, description, key_id)
    VALUES (
        new_secret,
        new_name,
        new_description,
        CASE WHEN new_key_id IS NULL THEN (pgsodium.create_key()).id ELSE new_key_id END)
    RETURNING id;
    $$;

alter function create_secret(text, text, text, uuid) owner to supabase_admin;


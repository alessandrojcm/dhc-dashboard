create function _missing(character, name, name[]) returns name[]
    language sql
as
$$
    SELECT _missing(ARRAY[$1], $2, $3);
$$;

alter function _missing(char, name, name[]) owner to supabase_admin;

grant execute on function _missing(char, name, name[]) to postgres with grant option;


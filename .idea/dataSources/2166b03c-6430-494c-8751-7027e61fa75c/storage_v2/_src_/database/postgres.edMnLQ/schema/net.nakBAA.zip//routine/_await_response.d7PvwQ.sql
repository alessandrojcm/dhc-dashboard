create function _await_response(request_id bigint) returns boolean
    strict
    parallel safe
    language plpgsql
as
$$
declare
    rec net._http_response;
begin
    while rec is null loop
        select *
        into rec
        from net._http_response
        where id = request_id;

        if rec is null then
            -- Wait 50 ms before checking again
            perform pg_sleep(0.05);
        end if;
    end loop;

    return true;
end;
$$;

alter function _await_response(bigint) owner to supabase_admin;


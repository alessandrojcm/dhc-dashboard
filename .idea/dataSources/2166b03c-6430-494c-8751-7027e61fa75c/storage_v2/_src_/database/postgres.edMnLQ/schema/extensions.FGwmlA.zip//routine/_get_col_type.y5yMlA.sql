create function _get_col_type(name, name, name) returns text
    language sql
as
$$
    SELECT pg_catalog.format_type(a.atttypid, a.atttypmod)
      FROM pg_catalog.pg_namespace n
      JOIN pg_catalog.pg_class c     ON n.oid = c.relnamespace
      JOIN pg_catalog.pg_attribute a ON c.oid = a.attrelid
     WHERE n.nspname = $1
       AND c.relname = $2
       AND a.attname = $3
       AND attnum    > 0
       AND NOT a.attisdropped
$$;

alter function _get_col_type(name, name, name) owner to supabase_admin;

grant execute on function _get_col_type(name, name, name) to postgres with grant option;


create function bag_eq(text, text) returns text
    language sql
as
$$
    SELECT _relcomp( $1, $2, NULL::text, 'ALL ' );
$$;

alter function bag_eq(text, text) owner to supabase_admin;

grant execute on function bag_eq(text, text) to postgres with grant option;


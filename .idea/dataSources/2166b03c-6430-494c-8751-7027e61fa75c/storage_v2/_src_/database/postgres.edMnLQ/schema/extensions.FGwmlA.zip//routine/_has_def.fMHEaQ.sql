create function _has_def(name, name) returns boolean
    language sql
as
$$
    SELECT a.atthasdef
      FROM pg_catalog.pg_class c
      JOIN pg_catalog.pg_attribute a ON c.oid = a.attrelid
     WHERE c.relname = $1
       AND a.attnum > 0
       AND NOT a.attisdropped
       AND a.attname = $2
       AND pg_catalog.pg_table_is_visible(c.oid)
$$;

alter function _has_def(name, name) owner to supabase_admin;

grant execute on function _has_def(name, name) to postgres with grant option;


create function get_supabase_uid(identifier text) returns uuid
    security definer
    SET search_path = auth, pg_temp
    language plpgsql
as
$$
DECLARE
    supabase_user uuid;
BEGIN
    SELECT id into supabase_user FROM auth.users WHERE raw_user_meta_data ->> 'test_identifier' = identifier limit 1;
    if supabase_user is null then
        RAISE EXCEPTION 'User with identifier % not found', identifier;
    end if;
    RETURN supabase_user;
END;
$$;

alter function get_supabase_uid(text) owner to postgres;

grant execute on function get_supabase_uid(text) to anon;

grant execute on function get_supabase_uid(text) to authenticated;

grant execute on function get_supabase_uid(text) to service_role;


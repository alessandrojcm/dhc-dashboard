create function _grolist(name) returns oid[]
    language sql
as
$$
    SELECT ARRAY(
        SELECT member
          FROM pg_catalog.pg_auth_members m
          JOIN pg_catalog.pg_roles r ON m.roleid = r.oid
         WHERE r.rolname =  $1
    );
$$;

alter function _grolist(name) owner to supabase_admin;

grant execute on function _grolist(name) to postgres with grant option;


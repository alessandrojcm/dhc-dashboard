create function views_are(name, name[], text) returns text
    language sql
as
$$
    SELECT _are( 'views', _extras('v', $1, $2), _missing('v', $1, $2), $3);
$$;

alter function views_are(name, name[], text) owner to supabase_admin;

grant execute on function views_are(name, name[], text) to postgres with grant option;


create function fk_ok(name, name, name, name, name, name, text) returns text
    language sql
as
$$
    SELECT fk_ok( $1, $2, ARRAY[$3], $4, $5, ARRAY[$6], $7 );
$$;

alter function fk_ok(name, name, name, name, name, name, text) owner to supabase_admin;

grant execute on function fk_ok(name, name, name, name, name, name, text) to postgres with grant option;


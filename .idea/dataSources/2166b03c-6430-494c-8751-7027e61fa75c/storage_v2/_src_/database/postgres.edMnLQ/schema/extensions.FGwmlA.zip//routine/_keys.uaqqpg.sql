create function _keys(name, character) returns SETOF name[]
    language sql
as
$$
    SELECT _pg_sv_column_array(x.conrelid,x.conkey) -- name[] doesn't support collation
      FROM pg_catalog.pg_class c
      JOIN pg_catalog.pg_constraint x  ON c.oid = x.conrelid
       AND c.relname = $1
       AND x.contype = $2
     WHERE pg_catalog.pg_table_is_visible(c.oid)
  ORDER BY 1
$$;

alter function _keys(name, char) owner to supabase_admin;

grant execute on function _keys(name, char) to postgres with grant option;


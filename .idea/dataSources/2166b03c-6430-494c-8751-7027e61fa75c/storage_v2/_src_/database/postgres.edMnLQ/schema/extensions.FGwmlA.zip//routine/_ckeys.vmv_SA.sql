create function _ckeys(name, character) returns name[]
    language sql
as
$$
    SELECT * FROM _keys($1, $2) LIMIT 1;
$$;

alter function _ckeys(name, char) owner to supabase_admin;

grant execute on function _ckeys(name, char) to postgres with grant option;


create view decrypted_secrets
            (id, name, description, secret, decrypted_secret, key_id, nonce, created_at, updated_at) as
SELECT secrets.id,
       secrets.name,
       secrets.description,
       secrets.secret,
       CASE
           WHEN secrets.secret IS NULL THEN NULL::text
           ELSE
               CASE
                   WHEN secrets.key_id IS NULL THEN NULL::text
                   ELSE convert_from(pgsodium.crypto_aead_det_decrypt(decode(secrets.secret, 'base64'::text),
                                                                      convert_to(
                                                                              ((secrets.id::text || secrets.description) ||
                                                                               secrets.created_at::text) ||
                                                                              secrets.updated_at::text, 'utf8'::name),
                                                                      secrets.key_id, secrets.nonce), 'utf8'::name)
                   END
           END AS decrypted_secret,
       secrets.key_id,
       secrets.nonce,
       secrets.created_at,
       secrets.updated_at
FROM vault.secrets;

alter table decrypted_secrets
    owner to supabase_admin;

grant delete, insert, references, select, trigger, truncate, update on decrypted_secrets to pgsodium_keyiduser;


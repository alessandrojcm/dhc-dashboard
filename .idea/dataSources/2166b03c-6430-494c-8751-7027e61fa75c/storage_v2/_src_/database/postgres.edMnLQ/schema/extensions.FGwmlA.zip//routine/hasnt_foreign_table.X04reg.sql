create function hasnt_foreign_table(name, name) returns text
    language sql
as
$$
    SELECT ok(
        NOT _rexists( 'f', $1, $2 ),
        'Foreign table ' || quote_ident($1) || '.' || quote_ident($2) || ' should not exist'
    );
$$;

alter function hasnt_foreign_table(name, name) owner to supabase_admin;

grant execute on function hasnt_foreign_table(name, name) to postgres with grant option;


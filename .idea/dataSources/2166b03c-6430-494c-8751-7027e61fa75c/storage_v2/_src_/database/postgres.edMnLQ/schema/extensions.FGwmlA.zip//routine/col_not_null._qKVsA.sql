create function col_not_null(table_name name, column_name name, description text DEFAULT NULL::text) returns text
    language sql
as
$$
    SELECT _col_is_null( $1, $2, $3, true );
$$;

alter function col_not_null(name, name, text) owner to supabase_admin;

grant execute on function col_not_null(name, name, text) to postgres with grant option;


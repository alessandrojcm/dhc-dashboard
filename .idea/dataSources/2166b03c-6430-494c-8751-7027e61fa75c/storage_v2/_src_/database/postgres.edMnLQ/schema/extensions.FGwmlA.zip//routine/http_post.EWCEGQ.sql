create function http_post(uri character varying, data jsonb) returns http_response
    language sql
as
$$
        SELECT extensions.http(('POST', $1, NULL, 'application/x-www-form-urlencoded', extensions.urlencode($2))::extensions.http_request)
    $$;

alter function http_post(varchar, jsonb) owner to supabase_admin;

grant execute on function http_post(varchar, jsonb) to postgres with grant option;


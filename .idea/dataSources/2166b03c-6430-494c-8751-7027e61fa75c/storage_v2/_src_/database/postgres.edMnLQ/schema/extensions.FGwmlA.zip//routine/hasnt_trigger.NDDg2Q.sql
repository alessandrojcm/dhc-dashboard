create function hasnt_trigger(name, name) returns text
    language sql
as
$$
    SELECT ok( NOT _trig($1, $2), 'Table ' || quote_ident($1) || ' should not have trigger ' || quote_ident($2));
$$;

alter function hasnt_trigger(name, name) owner to supabase_admin;

grant execute on function hasnt_trigger(name, name) to postgres with grant option;


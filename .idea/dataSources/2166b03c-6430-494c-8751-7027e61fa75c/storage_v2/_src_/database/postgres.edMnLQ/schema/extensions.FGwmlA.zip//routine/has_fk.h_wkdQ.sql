create function has_fk(name, text) returns text
    language sql
as
$$
    SELECT ok( _hasc( $1, 'f' ), $2 );
$$;

alter function has_fk(name, text) owner to supabase_admin;

grant execute on function has_fk(name, text) to postgres with grant option;


create function todo(how_many integer, why text) returns SETOF boolean
    language plpgsql
as
$$
BEGIN
    PERFORM _add('todo', COALESCE(how_many, 1), COALESCE(why, ''));
    RETURN;
END;
$$;

alter function todo(integer, text) owner to supabase_admin;

grant execute on function todo(integer, text) to postgres with grant option;


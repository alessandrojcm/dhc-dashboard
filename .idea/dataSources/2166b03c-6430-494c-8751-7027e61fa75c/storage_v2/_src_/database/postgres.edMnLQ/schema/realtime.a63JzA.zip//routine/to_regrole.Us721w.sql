create function to_regrole(role_name text) returns regrole
    immutable
    language sql
as
$$ select role_name::regrole $$;

alter function to_regrole(text) owner to supabase_admin;

grant execute on function to_regrole(text) to postgres;

grant execute on function to_regrole(text) to anon;

grant execute on function to_regrole(text) to authenticated;

grant execute on function to_regrole(text) to service_role;

grant execute on function to_regrole(text) to dashboard_user;

grant execute on function to_regrole(text) to supabase_realtime_admin;


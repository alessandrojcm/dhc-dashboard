create function hasnt_foreign_table(name, name, text) returns text
    language sql
as
$$
    SELECT ok( NOT _rexists( 'f', $1, $2 ), $3 );
$$;

alter function hasnt_foreign_table(name, name, text) owner to supabase_admin;

grant execute on function hasnt_foreign_table(name, name, text) to postgres with grant option;


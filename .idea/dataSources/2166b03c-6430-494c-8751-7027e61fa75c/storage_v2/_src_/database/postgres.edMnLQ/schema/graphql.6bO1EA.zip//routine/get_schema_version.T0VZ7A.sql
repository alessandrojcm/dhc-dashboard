create function get_schema_version(comment_ text) returns integer
    security definer
    language sql
as
$$
    select last_value from graphql.seq_schema_version;
$$;

alter function get_schema_version(text) owner to supabase_admin;

grant execute on function get_schema_version(text) to postgres;

grant execute on function get_schema_version(text) to anon;

grant execute on function get_schema_version(text) to authenticated;

grant execute on function get_schema_version(text) to service_role;


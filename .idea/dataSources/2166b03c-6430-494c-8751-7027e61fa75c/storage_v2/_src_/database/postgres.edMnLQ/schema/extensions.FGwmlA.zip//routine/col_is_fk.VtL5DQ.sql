create function col_is_fk(name, name) returns text
    language sql
as
$$
    SELECT col_is_fk( $1, $2, 'Column ' || quote_ident($1) || '(' || quote_ident($2) || ') should be a foreign key' );
$$;

alter function col_is_fk(name, name) owner to supabase_admin;

grant execute on function col_is_fk(name, name) to postgres with grant option;


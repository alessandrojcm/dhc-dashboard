create function has_sequence(name, text) returns text
    language sql
as
$$
    SELECT ok( _rexists( 'S', $1 ), $2 );
$$;

alter function has_sequence(name, text) owner to supabase_admin;

grant execute on function has_sequence(name, text) to postgres with grant option;


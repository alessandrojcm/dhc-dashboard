create function has_domain(name, text) returns text
    language sql
as
$$
    SELECT ok( _has_type( $1, ARRAY['d'] ), $2 );
$$;

alter function has_domain(name, text) owner to supabase_admin;

grant execute on function has_domain(name, text) to postgres with grant option;


create function throws_ok(text, text, text) returns text
    language plpgsql
as
$$
BEGIN
    IF octet_length($2) = 5 THEN
        RETURN throws_ok( $1, $2::char(5), $3, NULL );
    ELSE
        RETURN throws_ok( $1, NULL, $2, $3 );
    END IF;
END;
$$;

alter function throws_ok(text, text, text) owner to supabase_admin;

grant execute on function throws_ok(text, text, text) to postgres with grant option;


create function has_role(name) returns text
    language sql
as
$$
    SELECT ok( _has_role($1), 'Role ' || quote_ident($1) || ' should exist' );
$$;

alter function has_role(name) owner to supabase_admin;

grant execute on function has_role(name) to postgres with grant option;


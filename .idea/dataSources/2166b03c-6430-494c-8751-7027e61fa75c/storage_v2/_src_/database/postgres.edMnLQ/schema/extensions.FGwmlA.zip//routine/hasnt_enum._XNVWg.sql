create function hasnt_enum(name, text) returns text
    language sql
as
$$
    SELECT ok( NOT _has_type( $1, ARRAY['e'] ), $2 );
$$;

alter function hasnt_enum(name, text) owner to supabase_admin;

grant execute on function hasnt_enum(name, text) to postgres with grant option;


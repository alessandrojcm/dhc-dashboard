create function diag(VARIADIC text[]) returns text
    language sql
as
$$
    SELECT diag(array_to_string($1, ''));
$$;

alter function diag(text[]) owner to supabase_admin;

grant execute on function diag(text[]) to postgres with grant option;


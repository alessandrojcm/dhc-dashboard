create function insert_waitlist_entry(first_name text, last_name text, email text, date_of_birth timestamp with time zone, phone_number text, pronouns text, gender gender, medical_conditions text)
    returns TABLE(profile_id uuid, waitlist_id uuid, user_first_name text, user_last_name text, user_email text, user_date_of_birth date, user_phone_number text, user_pronouns text, user_gender gender, user_medical_conditions text)
    SET search_path = ""
    language plpgsql
as
$$
declare
    new_waitlist_id uuid;
begin
    begin
        insert into public.waitlist (email)
        values (email)
        returning id into new_waitlist_id;

        insert into public.user_profiles (first_name, last_name, date_of_birth, phone_number, pronouns, gender,
                                          is_active, waitlist_id, medical_conditions)
        values (first_name,
                last_name,
                date_of_birth,
                phone_number,
                pronouns,
                gender,
                false,
                new_waitlist_id,
                medical_conditions);

        RETURN QUERY
            SELECT u.id                 AS profile_id,
                   w.id                 AS waitlist_id,
                   u.first_name         AS user_first_name,
                   u.last_name          AS user_last_name,
                   w.email              AS user_email,
                   u.date_of_birth      AS user_date_of_birth,
                   u.phone_number       AS user_phone_number,
                   u.pronouns           AS user_pronouns,
                   u.gender             AS user_gender,
                   u.medical_conditions AS user_medical_conditions
            FROM public.waitlist w
                     JOIN public.user_profiles u ON w.id = u.waitlist_id
            WHERE w.id = new_waitlist_id;
    exception
        when others then
            raise;
    end;
end;
$$;

alter function insert_waitlist_entry(text, text, text, timestamp with time zone, text, text, gender, text) owner to postgres;

grant execute on function insert_waitlist_entry(text, text, text, timestamp with time zone, text, text, gender, text) to anon;

grant execute on function insert_waitlist_entry(text, text, text, timestamp with time zone, text, text, gender, text) to authenticated;

grant execute on function insert_waitlist_entry(text, text, text, timestamp with time zone, text, text, gender, text) to service_role;


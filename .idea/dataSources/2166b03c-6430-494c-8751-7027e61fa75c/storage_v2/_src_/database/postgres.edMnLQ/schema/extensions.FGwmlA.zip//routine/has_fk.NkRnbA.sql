create function has_fk(name, name, text) returns text
    language sql
as
$$
    SELECT ok( _hasc( $1, $2, 'f' ), $3 );
$$;

alter function has_fk(name, name, text) owner to supabase_admin;

grant execute on function has_fk(name, name, text) to postgres with grant option;


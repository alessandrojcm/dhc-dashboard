create function has_operator(name, name, name, name, name) returns text
    language sql
as
$$
    SELECT ok(
         _op_exists($1, $2, $3, $4, $5 ),
        'Operator ' || quote_ident($2) || '.' || $3 || '(' || $1 || ',' || $4
        || ') RETURNS ' || $5 || ' should exist'
    );
$$;

alter function has_operator(name, name, name, name, name) owner to supabase_admin;

grant execute on function has_operator(name, name, name, name, name) to postgres with grant option;


create function http_post(url text, body jsonb DEFAULT '{}'::jsonb, params jsonb DEFAULT '{}'::jsonb, headers jsonb DEFAULT '{"Content-Type": "application/json"}'::jsonb, timeout_milliseconds integer DEFAULT 5000) returns bigint
    security definer
    parallel safe
    SET search_path = net
    language plpgsql
as
$$
declare
    request_id bigint;
    params_array text[];
    content_type text;
begin

    -- Exctract the content_type from headers
    select
        header_value into content_type
    from
        jsonb_each_text(coalesce(headers, '{}'::jsonb)) r(header_name, header_value)
    where
        lower(header_name) = 'content-type'
    limit
        1;

    -- If the user provided new headers and omitted the content type
    -- add it back in automatically
    if content_type is null then
        select headers || '{"Content-Type": "application/json"}'::jsonb into headers;
    end if;

    -- Confirm that the content-type is set as "application/json"
    if content_type <> 'application/json' then
        raise exception 'Content-Type header must be "application/json"';
    end if;

    select
        coalesce(array_agg(net._urlencode_string(key) || '=' || net._urlencode_string(value)), '{}')
    into
        params_array
    from
        jsonb_each_text(params);

    -- Add to the request queue
    insert into net.http_request_queue(method, url, headers, body, timeout_milliseconds)
    values (
        'POST',
        net._encode_url_with_params_array(url, params_array),
        headers,
        convert_to(body::text, 'UTF8'),
        timeout_milliseconds
    )
    returning id
    into request_id;

    return request_id;
end
$$;

alter function http_post(text, jsonb, jsonb, jsonb, integer) owner to supabase_admin;

grant execute on function http_post(text, jsonb, jsonb, jsonb, integer) to postgres;

grant execute on function http_post(text, jsonb, jsonb, jsonb, integer) to anon;

grant execute on function http_post(text, jsonb, jsonb, jsonb, integer) to authenticated;

grant execute on function http_post(text, jsonb, jsonb, jsonb, integer) to service_role;

grant execute on function http_post(text, jsonb, jsonb, jsonb, integer) to supabase_functions_admin;


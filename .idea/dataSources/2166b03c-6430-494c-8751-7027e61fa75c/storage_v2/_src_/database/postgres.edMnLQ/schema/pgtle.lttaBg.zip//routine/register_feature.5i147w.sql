create function register_feature(proc regproc, feature pgtle.pg_tle_features) returns void
    language plpgsql
as
$$
DECLARE
pg_proc_relid oid;
proc_oid oid;
schema_name text;
nspoid oid;
proname text;
proc_schema_name text;
ident text;
passcheck_enabled text;
clientauth_enabled text;
current_db text;
passcheck_db text;
clientauth_db text;

BEGIN
    SELECT setting FROM pg_catalog.pg_settings WHERE name = 'pgtle.enable_password_check' INTO passcheck_enabled;
    SELECT setting FROM pg_catalog.pg_settings WHERE name = 'pgtle.enable_clientauth' INTO clientauth_enabled;
    SELECT pg_catalog.CURRENT_DATABASE() INTO current_db;
    SELECT setting FROM pg_catalog.pg_settings WHERE name = 'pgtle.passcheck_db_name' INTO passcheck_db;
    SELECT setting FROM pg_catalog.pg_settings WHERE name = 'pgtle.clientauth_db_name' INTO clientauth_db;

    IF feature = 'passcheck' THEN
        IF passcheck_enabled = 'off' THEN
           RAISE NOTICE 'pgtle.enable_password_check is set to off. To enable passcheck, set pgtle.enable_password_check = on';
        ELSE
        -- passcheck_db_name is an optional param, we only emit a warning if it's non-empty and is not the current database
            IF passcheck_db != '' AND current_db != passcheck_db THEN
                RAISE NOTICE '%', pg_catalog.FORMAT('pgtle.passcheck_db_name is currently %I. To trigger this passcheck function, register the function in that database.', passcheck_db)
                USING HINT = pg_catalog.FORMAT('Alternatively, to use the current database for passcheck, set pgtle.passcheck_db_name = %I and reload the PostgreSQL configuration.', current_db);
            END IF;
        END IF;
    END IF;

    IF feature = 'clientauth' THEN
        IF clientauth_enabled = 'off' THEN
            RAISE NOTICE 'pgtle.enable_clientauth is set to off. To enable clientauth, set pgtle.enable_clientauth = on';
        ELSE
            IF current_db != clientauth_db THEN
                RAISE NOTICE '%', pg_catalog.FORMAT('pgtle.clientauth_db_name is currently %I. To trigger this clientauth function, register the function in that database.', clientauth_db)
                USING HINT = pg_catalog.FORMAT('Alternatively, to use the current database for clientauth, set pgtle.clientauth_db_name = %I and reload the PostgreSQL configuration.', current_db);
            END IF;
        END IF;
    END IF;

    SELECT oid into nspoid FROM pg_catalog.pg_namespace
    where nspname = 'pg_catalog';

    SELECT oid into pg_proc_relid from pg_catalog.pg_class
    where relname = 'pg_proc' and relnamespace = nspoid;

    SELECT pg_namespace.nspname, pg_proc.oid, pg_proc.proname into proc_schema_name, proc_oid, proname FROM
                                                                                                           pg_catalog.pg_namespace, pg_catalog.pg_proc
    where pg_proc.oid = proc AND pg_proc.pronamespace = pg_namespace.oid;

    SELECT identity into ident FROM pg_catalog.pg_identify_object(pg_proc_relid, proc_oid, 0);

    INSERT INTO pgtle.feature_info VALUES (feature, proc_schema_name, proname, ident);
END;
$$;

alter function register_feature(regproc, pgtle.pg_tle_features) owner to supabase_admin;

grant execute on function register_feature(regproc, pgtle.pg_tle_features) to pgtle_admin;


create function fail() returns text
    language sql
as
$$
    SELECT ok( FALSE, NULL );
$$;

alter function fail() owner to supabase_admin;

grant execute on function fail() to postgres with grant option;


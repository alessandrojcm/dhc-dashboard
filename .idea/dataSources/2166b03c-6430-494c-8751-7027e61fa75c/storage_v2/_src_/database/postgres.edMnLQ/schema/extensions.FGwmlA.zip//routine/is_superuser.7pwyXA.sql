create function is_superuser(name, text) returns text
    language plpgsql
as
$$
DECLARE
    is_super boolean := _is_super($1);
BEGIN
    IF is_super IS NULL THEN
        RETURN fail( $2 ) || E'\n' || diag( '    User ' || quote_ident($1) || ' does not exist') ;
    END IF;
    RETURN ok( is_super, $2 );
END;
$$;

alter function is_superuser(name, text) owner to supabase_admin;

grant execute on function is_superuser(name, text) to postgres with grant option;


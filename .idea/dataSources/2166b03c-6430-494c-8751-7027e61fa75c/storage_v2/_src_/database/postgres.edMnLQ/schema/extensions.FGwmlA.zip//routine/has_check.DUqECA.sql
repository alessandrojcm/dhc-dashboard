create function has_check(name) returns text
    language sql
as
$$
    SELECT has_check( $1, 'Table ' || quote_ident($1) || ' should have a check constraint' );
$$;

alter function has_check(name) owner to supabase_admin;

grant execute on function has_check(name) to postgres with grant option;


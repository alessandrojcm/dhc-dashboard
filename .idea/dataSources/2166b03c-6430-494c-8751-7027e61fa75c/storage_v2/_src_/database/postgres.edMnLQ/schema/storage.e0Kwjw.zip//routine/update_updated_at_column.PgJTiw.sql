create function update_updated_at_column(prefix text, bucketname text, limits integer, levels integer, offsets integer, search text, sortcolumn text, sortorder text) returns trigger
    language plpgsql
as
$$
BEGIN
    NEW.updated_at = now();
    RETURN NEW; 
END;
$$;

alter function update_updated_at_column(text, text, integer, integer, integer, text, text, text) owner to supabase_storage_admin;


create function has_index(name, name, text) returns text
    language sql
as
$$
    SELECT CASE WHEN $3 LIKE '%(%'
           THEN has_index( $1, $2, $3::name )
           ELSE ok( _have_index( $1, $2 ), $3 )
           END;
$$;

alter function has_index(name, name, text) owner to supabase_admin;

grant execute on function has_index(name, name, text) to postgres with grant option;


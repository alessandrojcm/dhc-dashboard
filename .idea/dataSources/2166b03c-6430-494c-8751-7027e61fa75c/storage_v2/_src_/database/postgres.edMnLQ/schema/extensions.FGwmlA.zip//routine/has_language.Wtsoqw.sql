create function has_language(name, text) returns text
    language sql
as
$$
    SELECT ok( _is_trusted($1) IS NOT NULL, $2 );
$$;

alter function has_language(name, text) owner to supabase_admin;

grant execute on function has_language(name, text) to postgres with grant option;


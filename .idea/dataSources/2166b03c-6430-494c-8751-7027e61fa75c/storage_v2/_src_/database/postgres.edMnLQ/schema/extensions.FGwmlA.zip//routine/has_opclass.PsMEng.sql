create function has_opclass(name, name, text) returns text
    language sql
as
$$
    SELECT ok( _opc_exists( $1, $2 ), $3 );
$$;

alter function has_opclass(name, name, text) owner to supabase_admin;

grant execute on function has_opclass(name, name, text) to postgres with grant option;


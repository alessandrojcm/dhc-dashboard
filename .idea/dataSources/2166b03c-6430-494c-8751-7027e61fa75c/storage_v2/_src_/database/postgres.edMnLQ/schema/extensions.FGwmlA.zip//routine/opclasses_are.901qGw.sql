create function opclasses_are(name, name[]) returns text
    language sql
as
$$
    SELECT opclasses_are( $1, $2, 'Schema ' || quote_ident($1) || ' should have the correct operator classes' );
$$;

alter function opclasses_are(name, name[]) owner to supabase_admin;

grant execute on function opclasses_are(name, name[]) to postgres with grant option;


create function http_post(uri character varying, content character varying, content_type character varying) returns http_response
    language sql
as
$$ SELECT extensions.http(('POST', $1, NULL, $3, $2)::extensions.http_request) $$;

alter function http_post(varchar, varchar, varchar) owner to supabase_admin;

grant execute on function http_post(varchar, varchar, varchar) to postgres with grant option;


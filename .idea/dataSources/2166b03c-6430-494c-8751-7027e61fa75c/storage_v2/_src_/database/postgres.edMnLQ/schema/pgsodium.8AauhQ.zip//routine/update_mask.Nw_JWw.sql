create function update_mask(target oid, debug boolean DEFAULT false) returns void
    security definer
    SET search_path = ""
    language plpgsql
as
$$
BEGIN
  PERFORM pgsodium.disable_security_label_trigger();
  PERFORM pgsodium.create_mask_view(objoid, objsubid, debug)
    FROM pg_catalog.pg_seclabel sl
    WHERE sl.objoid = target
      AND sl.label ILIKE 'ENCRYPT%'
      AND sl.provider = 'pgsodium';
  PERFORM pgsodium.enable_security_label_trigger();
  RETURN;
END
$$;

alter function update_mask(oid, boolean) owner to supabase_admin;


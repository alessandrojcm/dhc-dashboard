create function col_has_check(name, name) returns text
    language sql
as
$$
    SELECT col_has_check( $1, $2, 'Column ' || quote_ident($1) || '(' || quote_ident($2) || ') should have a check constraint' );
$$;

alter function col_has_check(name, name) owner to supabase_admin;

grant execute on function col_has_check(name, name) to postgres with grant option;


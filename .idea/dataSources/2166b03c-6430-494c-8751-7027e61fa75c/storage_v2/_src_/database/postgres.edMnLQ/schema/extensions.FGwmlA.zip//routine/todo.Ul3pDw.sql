create function todo(why text) returns SETOF boolean
    language plpgsql
as
$$
BEGIN
    PERFORM _add('todo', 1, COALESCE(why, ''));
    RETURN;
END;
$$;

alter function todo(text) owner to supabase_admin;

grant execute on function todo(text) to postgres with grant option;


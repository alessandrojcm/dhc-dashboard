create function hasnt_relation(name, text) returns text
    language sql
as
$$
    SELECT ok( NOT _relexists( $1 ), $2 );
$$;

alter function hasnt_relation(name, text) owner to supabase_admin;

grant execute on function hasnt_relation(name, text) to postgres with grant option;


create function get_membership_info(uid uuid) returns jsonb
    stable
    SET search_path = ""
    language plpgsql
as
$$
begin
    if uid is null then
        return jsonb_build_object(
            'error', jsonb_build_object(
                'http_code', 400,
                'message', 'User ID cannot be null.'
            )
        );
    end if;

    return (
        with user_check as (
            select u.id, u.email
            from auth.users u
            where u.id = uid
              and u.banned_until < now()
        ),
        profile_info as (
            select up.first_name,
                   up.last_name,
                   up.phone_number,
                   up.date_of_birth,
                   up.pronouns,
                   up.gender,
                   case
                       when mp.id is not null then
                           jsonb_build_object(
                               'error', jsonb_build_object(
                                   'http_code', 400,
                                   'message', 'User already active.'
                               )
                           )
                       when uc.id is null then
                           jsonb_build_object(
                               'error', jsonb_build_object(
                                   'http_code', 403,
                                   'message', 'User is deactivated.'
                               )
                           )
                       else
                           jsonb_build_object(
                               'first_name', up.first_name,
                               'last_name', up.last_name,
                               'phone_number', up.phone_number,
                               'date_of_birth', up.date_of_birth,
                               'pronouns', up.pronouns,
                               'gender', up.gender
                           )
                   end as result
            from user_check uc
                     left join public.waitlist w on w.email = uc.email
                     left join public.user_profiles up on up.waitlist_id = w.id
                     left join public.member_profiles mp on mp.user_profile_id = up.id
        )
        select coalesce(
            (select result from profile_info where result is not null limit 1),
            null::jsonb
        )
    );
end;
$$;

alter function get_membership_info(uuid) owner to postgres;

grant execute on function get_membership_info(uuid) to anon;

grant execute on function get_membership_info(uuid) to authenticated;

grant execute on function get_membership_info(uuid) to service_role;


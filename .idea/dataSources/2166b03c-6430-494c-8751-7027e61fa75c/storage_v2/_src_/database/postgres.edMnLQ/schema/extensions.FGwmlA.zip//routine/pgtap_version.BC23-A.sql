create function pgtap_version() returns numeric
    immutable
    language sql
as
$$SELECT 1.2;$$;

alter function pgtap_version() owner to supabase_admin;

grant execute on function pgtap_version() to postgres with grant option;


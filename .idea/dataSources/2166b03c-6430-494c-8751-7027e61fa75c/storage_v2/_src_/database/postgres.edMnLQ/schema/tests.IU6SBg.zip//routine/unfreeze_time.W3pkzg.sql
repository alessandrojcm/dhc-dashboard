create function unfreeze_time() returns void
    language plpgsql
as
$$
BEGIN
    -- restore the original now function
    PERFORM set_config('tests.frozen_time', null, true);
    -- restore the original search path
    PERFORM set_config('search_path', current_setting('tests.original_search_path'), true);
END
$$;

alter function unfreeze_time() owner to postgres;

grant execute on function unfreeze_time() to anon;

grant execute on function unfreeze_time() to authenticated;

grant execute on function unfreeze_time() to service_role;


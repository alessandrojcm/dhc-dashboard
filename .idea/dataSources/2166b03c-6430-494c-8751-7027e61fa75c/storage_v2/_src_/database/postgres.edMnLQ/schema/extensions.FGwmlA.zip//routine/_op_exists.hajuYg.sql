create function _op_exists(name, name, name) returns boolean
    language sql
as
$$
    SELECT EXISTS (
       SELECT TRUE
         FROM pg_catalog.pg_operator o
        WHERE pg_catalog.pg_operator_is_visible(o.oid)
          AND o.oprname = $2
          AND CASE o.oprkind WHEN 'l' THEN $1 IS NULL
              ELSE _cmp_types(o.oprleft, $1) END
          AND CASE o.oprkind WHEN 'r' THEN $3 IS NULL
              ELSE _cmp_types(o.oprright, $3) END
   );
$$;

alter function _op_exists(name, name, name) owner to supabase_admin;

grant execute on function _op_exists(name, name, name) to postgres with grant option;


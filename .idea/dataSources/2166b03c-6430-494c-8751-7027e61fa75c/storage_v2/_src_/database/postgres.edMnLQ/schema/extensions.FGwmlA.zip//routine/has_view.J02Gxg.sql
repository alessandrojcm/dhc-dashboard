create function has_view(name, text) returns text
    language sql
as
$$
    SELECT ok( _rexists( 'v', $1 ), $2 );
$$;

alter function has_view(name, text) owner to supabase_admin;

grant execute on function has_view(name, text) to postgres with grant option;


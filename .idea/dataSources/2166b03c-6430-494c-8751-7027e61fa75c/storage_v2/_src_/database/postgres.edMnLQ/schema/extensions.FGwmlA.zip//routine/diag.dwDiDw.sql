create function diag(msg text) returns text
    strict
    language sql
as
$$
    SELECT '# ' || replace(
       replace(
            replace( $1, E'\r\n', E'\n# ' ),
            E'\n',
            E'\n# '
        ),
        E'\r',
        E'\n# '
    );
$$;

alter function diag(text) owner to supabase_admin;

grant execute on function diag(text) to postgres with grant option;


create function sequences_are(name[], text) returns text
    language sql
as
$$
    SELECT _are( 'sequences', _extras('S', $1), _missing('S', $1), $2);
$$;

alter function sequences_are(name[], text) owner to supabase_admin;

grant execute on function sequences_are(name[], text) to postgres with grant option;


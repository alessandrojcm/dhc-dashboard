create function col_is_fk(name, name, name, text) returns text
    language sql
as
$$
    SELECT col_is_fk( $1, $2, ARRAY[$3], $4 );
$$;

alter function col_is_fk(name, name, name, text) owner to supabase_admin;

grant execute on function col_is_fk(name, name, name, text) to postgres with grant option;


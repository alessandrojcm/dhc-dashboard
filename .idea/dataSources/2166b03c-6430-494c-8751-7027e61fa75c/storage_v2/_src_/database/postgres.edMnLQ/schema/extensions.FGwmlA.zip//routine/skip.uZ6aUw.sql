create function skip(integer, text) returns text
    language sql
as
$$SELECT skip($2, $1)$$;

alter function skip(integer, text) owner to supabase_admin;

grant execute on function skip(integer, text) to postgres with grant option;


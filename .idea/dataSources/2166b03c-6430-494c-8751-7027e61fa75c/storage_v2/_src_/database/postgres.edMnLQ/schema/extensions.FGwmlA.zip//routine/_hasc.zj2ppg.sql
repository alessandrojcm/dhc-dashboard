create function _hasc(name, character) returns boolean
    language sql
as
$$
    SELECT EXISTS(
            SELECT true
              FROM pg_catalog.pg_class c
              JOIN pg_catalog.pg_constraint x ON c.oid = x.conrelid
             WHERE pg_table_is_visible(c.oid)
               AND c.relname = $1
               AND x.contype = $2
    );
$$;

alter function _hasc(name, char) owner to supabase_admin;

grant execute on function _hasc(name, char) to postgres with grant option;


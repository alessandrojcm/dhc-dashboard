create function has_foreign_table(name, name, text) returns text
    language sql
as
$$
    SELECT ok( _rexists( 'f', $1, $2 ), $3 );
$$;

alter function has_foreign_table(name, name, text) owner to supabase_admin;

grant execute on function has_foreign_table(name, name, text) to postgres with grant option;


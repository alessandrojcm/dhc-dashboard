create function todo_end() returns SETOF boolean
    language plpgsql
as
$$
DECLARE
    id integer;
BEGIN
    id := _get_latest( 'todo', -1 );
    IF id IS NULL THEN
        RAISE EXCEPTION 'todo_end() called without todo_start()';
    END IF;
    EXECUTE 'DELETE FROM __tcache__ WHERE id = ' || id;
    RETURN;
END;
$$;

alter function todo_end() owner to supabase_admin;

grant execute on function todo_end() to postgres with grant option;


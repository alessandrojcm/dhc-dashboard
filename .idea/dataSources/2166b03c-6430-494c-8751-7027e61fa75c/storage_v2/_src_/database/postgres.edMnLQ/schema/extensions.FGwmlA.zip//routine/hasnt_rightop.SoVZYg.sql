create function hasnt_rightop(name, name, text) returns text
    language sql
as
$$
    SELECT ok( NOT _op_exists( $1, $2, NULL), $3 );
$$;

alter function hasnt_rightop(name, name, text) owner to supabase_admin;

grant execute on function hasnt_rightop(name, name, text) to postgres with grant option;


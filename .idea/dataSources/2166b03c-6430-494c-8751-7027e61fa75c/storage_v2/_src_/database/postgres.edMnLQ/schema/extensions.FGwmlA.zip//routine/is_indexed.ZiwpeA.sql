create function is_indexed(name, name, name) returns text
    language sql
as
$$
    SELECT CASE WHEN _is_schema( $1 ) THEN
                -- Looking for schema.table index.
                is_indexed( $1, $2, ARRAY[$3]::NAME[] )
           ELSE
                -- Looking for particular columns.
                is_indexed( $1, ARRAY[$2]::NAME[], $3 )
           END;
$$;

alter function is_indexed(name, name, name) owner to supabase_admin;

grant execute on function is_indexed(name, name, name) to postgres with grant option;


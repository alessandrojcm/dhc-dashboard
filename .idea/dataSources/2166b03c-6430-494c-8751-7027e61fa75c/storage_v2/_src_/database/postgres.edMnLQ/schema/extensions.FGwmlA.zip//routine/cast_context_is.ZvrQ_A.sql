create function cast_context_is(name, name, text) returns text
    language sql
as
$$
    SELECT cast_context_is(
        $1, $2, $3,
        'Cast (' || quote_ident($1) || ' AS ' || quote_ident($2)
        || ') context should be ' || _expand_context(substring(LOWER($3) FROM 1 FOR 1))
    );
$$;

alter function cast_context_is(name, name, text) owner to supabase_admin;

grant execute on function cast_context_is(name, name, text) to postgres with grant option;


create function hasnt_function(name, text) returns text
    language sql
as
$$
    SELECT ok( NOT _got_func($1), $2 );
$$;

alter function hasnt_function(name, text) owner to supabase_admin;

grant execute on function hasnt_function(name, text) to postgres with grant option;


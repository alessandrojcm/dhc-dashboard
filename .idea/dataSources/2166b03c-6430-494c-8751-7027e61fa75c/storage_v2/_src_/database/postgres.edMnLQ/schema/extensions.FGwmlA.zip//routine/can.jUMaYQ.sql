create function can(name, name[]) returns text
    language sql
as
$$
    SELECT can( $1, $2, 'Schema ' || quote_ident($1) || ' can' );
$$;

alter function can(name, name[]) owner to supabase_admin;

grant execute on function can(name, name[]) to postgres with grant option;


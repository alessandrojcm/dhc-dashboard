create function has_group(name, text) returns text
    language sql
as
$$
    SELECT ok( _has_group($1), $2 );
$$;

alter function has_group(name, text) owner to supabase_admin;

grant execute on function has_group(name, text) to postgres with grant option;


create function hasnt_tablespace(name, text) returns text
    language sql
as
$$
    SELECT ok(
        NOT EXISTS(
            SELECT true
              FROM pg_catalog.pg_tablespace
             WHERE spcname = $1
        ), $2
    );
$$;

alter function hasnt_tablespace(name, text) owner to supabase_admin;

grant execute on function hasnt_tablespace(name, text) to postgres with grant option;


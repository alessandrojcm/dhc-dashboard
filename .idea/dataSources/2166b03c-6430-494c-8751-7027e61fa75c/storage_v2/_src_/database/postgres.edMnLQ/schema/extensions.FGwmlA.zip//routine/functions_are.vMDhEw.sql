create function functions_are(name[]) returns text
    language sql
as
$$
    SELECT functions_are( $1, 'Search path ' || pg_catalog.current_setting('search_path') || ' should have the correct functions' );
$$;

alter function functions_are(name[]) owner to supabase_admin;

grant execute on function functions_are(name[]) to postgres with grant option;


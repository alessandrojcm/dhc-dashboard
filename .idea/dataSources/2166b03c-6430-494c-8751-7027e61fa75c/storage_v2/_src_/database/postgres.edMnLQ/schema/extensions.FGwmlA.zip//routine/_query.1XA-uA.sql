create function _query(text) returns text
    language sql
as
$$
    SELECT CASE
        WHEN $1 LIKE '"%' OR $1 !~ '[[:space:]]' THEN 'EXECUTE ' || $1
        ELSE $1
    END;
$$;

alter function _query(text) owner to supabase_admin;

grant execute on function _query(text) to postgres with grant option;


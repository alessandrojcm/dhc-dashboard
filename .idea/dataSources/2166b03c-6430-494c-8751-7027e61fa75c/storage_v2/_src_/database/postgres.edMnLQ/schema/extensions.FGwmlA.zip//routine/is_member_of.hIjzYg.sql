create function is_member_of(name, name[]) returns text
    language sql
as
$$
    SELECT is_member_of( $1, $2, 'Should have members of role ' || quote_ident($1) );
$$;

alter function is_member_of(name, name[]) owner to supabase_admin;

grant execute on function is_member_of(name, name[]) to postgres with grant option;


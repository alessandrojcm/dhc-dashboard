create function hasnt_user(name, text) returns text
    language sql
as
$$
    SELECT ok( NOT _has_user($1), $2 );
$$;

alter function hasnt_user(name, text) owner to supabase_admin;

grant execute on function hasnt_user(name, text) to postgres with grant option;


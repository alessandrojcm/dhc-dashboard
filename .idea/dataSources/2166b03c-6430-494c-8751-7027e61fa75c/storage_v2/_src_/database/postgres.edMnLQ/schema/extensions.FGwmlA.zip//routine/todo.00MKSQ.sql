create function todo(how_many integer) returns SETOF boolean
    language plpgsql
as
$$
BEGIN
    PERFORM _add('todo', COALESCE(how_many, 1), '');
    RETURN;
END;
$$;

alter function todo(integer) owner to supabase_admin;

grant execute on function todo(integer) to postgres with grant option;


create function now() returns timestamp with time zone
    language plpgsql
as
$$
BEGIN


    -- check if a frozen time is set
    IF nullif(current_setting('tests.frozen_time'), '') IS NOT NULL THEN
        RETURN current_setting('tests.frozen_time')::timestamptz;
    END IF;

    RETURN pg_catalog.now();
END
$$;

alter function now() owner to postgres;

grant execute on function now() to anon;

grant execute on function now() to authenticated;

grant execute on function now() to service_role;


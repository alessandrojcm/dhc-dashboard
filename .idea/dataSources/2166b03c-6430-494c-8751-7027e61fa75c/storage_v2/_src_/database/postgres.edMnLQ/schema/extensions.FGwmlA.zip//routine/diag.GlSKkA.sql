create function diag(msg anyelement) returns text
    language sql
as
$$
    SELECT diag($1::text);
$$;

alter function diag(anyelement) owner to supabase_admin;

grant execute on function diag(anyelement) to postgres with grant option;


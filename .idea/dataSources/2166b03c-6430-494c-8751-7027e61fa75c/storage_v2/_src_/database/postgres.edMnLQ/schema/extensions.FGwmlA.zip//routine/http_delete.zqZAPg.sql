create function http_delete(uri character varying) returns http_response
    language sql
as
$$ SELECT extensions.http(('DELETE', $1, NULL, NULL, NULL)::extensions.http_request) $$;

alter function http_delete(varchar) owner to supabase_admin;

grant execute on function http_delete(varchar) to postgres with grant option;


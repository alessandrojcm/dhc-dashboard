create function hasnt_column(name, name, name, text) returns text
    language sql
as
$$
    SELECT ok( NOT _cexists( $1, $2, $3 ), $4 );
$$;

alter function hasnt_column(name, name, name, text) owner to supabase_admin;

grant execute on function hasnt_column(name, name, name, text) to postgres with grant option;


create function has_composite(name, text) returns text
    language sql
as
$$
    SELECT ok( _rexists( 'c', $1 ), $2 );
$$;

alter function has_composite(name, text) owner to supabase_admin;

grant execute on function has_composite(name, text) to postgres with grant option;


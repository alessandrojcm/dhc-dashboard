create function has_schema(name) returns text
    language sql
as
$$
    SELECT has_schema( $1, 'Schema ' || quote_ident($1) || ' should exist' );
$$;

alter function has_schema(name) owner to supabase_admin;

grant execute on function has_schema(name) to postgres with grant option;


create function _expand_context(character) returns text
    immutable
    language sql
as
$$
   SELECT CASE $1
          WHEN 'i' THEN 'implicit'
          WHEN 'a' THEN 'assignment'
          WHEN 'e' THEN 'explicit'
          ELSE          'unknown' END
$$;

alter function _expand_context(char) owner to supabase_admin;

grant execute on function _expand_context(char) to postgres with grant option;


create function bag_eq(text, text, text) returns text
    language sql
as
$$
    SELECT _relcomp( $1, $2, $3, 'ALL ' );
$$;

alter function bag_eq(text, text, text) owner to supabase_admin;

grant execute on function bag_eq(text, text, text) to postgres with grant option;


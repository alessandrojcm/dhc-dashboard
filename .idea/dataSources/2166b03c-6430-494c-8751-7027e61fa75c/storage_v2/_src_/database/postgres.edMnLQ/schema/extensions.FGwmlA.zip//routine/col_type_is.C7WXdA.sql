create function col_type_is(name, name, text, text) returns text
    language sql
as
$$
    SELECT col_type_is( NULL, $1, $2, $3, $4 );
$$;

alter function col_type_is(name, name, text, text) owner to supabase_admin;

grant execute on function col_type_is(name, name, text, text) to postgres with grant option;


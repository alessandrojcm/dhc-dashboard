create function col_has_check(name, name, name[], text) returns text
    language sql
as
$$
    SELECT _constraint( $1, $2, 'c', $3, $4, 'check' );
$$;

alter function col_has_check(name, name, name[], text) owner to supabase_admin;

grant execute on function col_has_check(name, name, name[], text) to postgres with grant option;


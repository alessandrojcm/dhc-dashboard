create function operation() returns text
    stable
    language plpgsql
as
$$
BEGIN
    RETURN current_setting('storage.operation', true);
END;
$$;

alter function operation() owner to supabase_storage_admin;


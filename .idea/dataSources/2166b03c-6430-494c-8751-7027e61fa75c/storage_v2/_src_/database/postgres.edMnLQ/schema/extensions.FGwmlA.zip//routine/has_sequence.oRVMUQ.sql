create function has_sequence(name, name) returns text
    language sql
as
$$
    SELECT ok(
        _rexists( 'S', $1, $2 ),
        'Sequence ' || quote_ident($1) || '.' || quote_ident($2) || ' should exist'
    );
$$;

alter function has_sequence(name, name) owner to supabase_admin;

grant execute on function has_sequence(name, name) to postgres with grant option;


create function views_are(name[]) returns text
    language sql
as
$$
    SELECT _are(
        'views', _extras('v', $1), _missing('v', $1),
        'Search path ' || pg_catalog.current_setting('search_path') || ' should have the correct views'
    );
$$;

alter function views_are(name[]) owner to supabase_admin;

grant execute on function views_are(name[]) to postgres with grant option;


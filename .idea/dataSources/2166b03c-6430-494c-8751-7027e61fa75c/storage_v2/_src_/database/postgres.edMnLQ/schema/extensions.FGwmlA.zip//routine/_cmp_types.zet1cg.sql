create function _cmp_types(oid, name) returns boolean
    language plpgsql
as
$$
DECLARE
    dtype TEXT := pg_catalog.format_type($1, NULL);
BEGIN
    RETURN dtype = _quote_ident_like($2, dtype);
END;
$$;

alter function _cmp_types(oid, name) owner to supabase_admin;

grant execute on function _cmp_types(oid, name) to postgres with grant option;


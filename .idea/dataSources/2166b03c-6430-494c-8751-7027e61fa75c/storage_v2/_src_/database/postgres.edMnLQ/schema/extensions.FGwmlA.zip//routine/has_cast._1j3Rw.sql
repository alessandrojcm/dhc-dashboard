create function has_cast(name, name, name, name) returns text
    language sql
as
$$
   SELECT ok(
       _cast_exists( $1, $2, $3, $4 ),
        'Cast (' || quote_ident($1) || ' AS ' || quote_ident($2)
        || ') WITH FUNCTION ' || quote_ident($3)
        || '.' || quote_ident($4) || '() should exist'
    );
$$;

alter function has_cast(name, name, name, name) owner to supabase_admin;

grant execute on function has_cast(name, name, name, name) to postgres with grant option;


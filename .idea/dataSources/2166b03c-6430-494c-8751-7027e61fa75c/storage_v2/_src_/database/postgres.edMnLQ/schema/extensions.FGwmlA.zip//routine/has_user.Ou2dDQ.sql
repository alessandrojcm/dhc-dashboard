create function has_user(name) returns text
    language sql
as
$$
    SELECT ok( _has_user( $1 ), 'User ' || quote_ident($1) || ' should exist');
$$;

alter function has_user(name) owner to supabase_admin;

grant execute on function has_user(name) to postgres with grant option;


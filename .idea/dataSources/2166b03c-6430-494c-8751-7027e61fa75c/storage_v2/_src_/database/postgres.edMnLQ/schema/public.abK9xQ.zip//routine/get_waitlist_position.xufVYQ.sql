create function get_waitlist_position(p_waitlist_id uuid) returns integer
    language plpgsql
as
$$
begin
    return (select position
            from (select id,
                         row_number() over (
                             order by
                                 initial_registration_date
                             ) as position
                  from waitlist
                  where status = 'waiting') as positions
            where id = p_waitlist_id);
end;
$$;

alter function get_waitlist_position(uuid) owner to postgres;

grant execute on function get_waitlist_position(uuid) to anon;

grant execute on function get_waitlist_position(uuid) to authenticated;

grant execute on function get_waitlist_position(uuid) to service_role;


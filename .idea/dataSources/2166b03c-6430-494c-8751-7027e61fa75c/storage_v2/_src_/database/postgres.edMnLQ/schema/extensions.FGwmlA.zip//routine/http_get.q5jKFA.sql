create function http_get(uri character varying) returns http_response
    language sql
as
$$ SELECT extensions.http(('GET', $1, NULL, NULL, NULL)::extensions.http_request) $$;

alter function http_get(varchar) owner to supabase_admin;

grant execute on function http_get(varchar) to postgres with grant option;


create function has_pk(name, name, text) returns text
    language sql
as
$$
    SELECT ok( _hasc( $1, $2, 'p' ), $3 );
$$;

alter function has_pk(name, name, text) owner to supabase_admin;

grant execute on function has_pk(name, name, text) to postgres with grant option;


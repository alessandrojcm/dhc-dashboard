create function has_table(name, text) returns text
    language sql
as
$$
    SELECT ok( _rexists( '{r,p}'::char[], $1 ), $2 );
$$;

alter function has_table(name, text) owner to supabase_admin;

grant execute on function has_table(name, text) to postgres with grant option;


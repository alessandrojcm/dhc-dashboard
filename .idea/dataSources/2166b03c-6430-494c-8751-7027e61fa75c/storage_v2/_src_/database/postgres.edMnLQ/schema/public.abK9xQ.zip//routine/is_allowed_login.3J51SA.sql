create function is_allowed_login() returns boolean
    security definer
    language plpgsql
as
$$
declare
    discord_id text;
begin
    -- Get the user's discord id from auth.jwt()
    discord_id := (select raw_user_meta_data ->> 'discord_id' from auth.users where id = auth.uid());

    -- Check if user exists in user_profiles and is active
    return exists (select 1
                   from user_profiles
                   where discord_id = discord_id
                     and is_active = true);
end;
$$;

alter function is_allowed_login() owner to postgres;

grant execute on function is_allowed_login() to anon;

grant execute on function is_allowed_login() to authenticated;

grant execute on function is_allowed_login() to service_role;


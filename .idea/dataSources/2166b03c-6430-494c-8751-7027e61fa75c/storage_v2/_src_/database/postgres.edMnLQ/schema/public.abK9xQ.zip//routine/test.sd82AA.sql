create function test() returns jsonb
    language plpgsql
as
$$
declare
    user_roles public.role_type[];
    arr jsonb;
begin
select array_agg(role) into user_roles from public.user_roles where user_id = 'ec272407-1ad3-4e96-bbdf-a0f175e8fdde';
arr := jsonb_build_object(
       'claims', user_roles
       );

return arr;
end;
    $$;

alter function test() owner to postgres;

grant execute on function test() to anon;

grant execute on function test() to authenticated;

grant execute on function test() to service_role;


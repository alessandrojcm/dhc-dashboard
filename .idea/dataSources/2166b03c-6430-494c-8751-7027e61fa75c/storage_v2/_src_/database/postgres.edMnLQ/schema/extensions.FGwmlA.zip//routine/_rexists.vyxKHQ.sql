create function _rexists(character, name) returns boolean
    language sql
as
$$
SELECT _rexists(ARRAY[$1], $2);
$$;

alter function _rexists(char, name) owner to supabase_admin;

grant execute on function _rexists(char, name) to postgres with grant option;


create function crypto_shorthash(message bytea, key_uuid uuid) returns bytea
    stable
    security definer
    SET search_path = ""
    language plpgsql
as
$$
DECLARE
  key pgsodium.decrypted_key;
BEGIN
  SELECT * INTO STRICT key
    FROM pgsodium.decrypted_key v
  WHERE id = key_uuid AND key_type = 'shorthash';

  IF key.decrypted_raw_key IS NOT NULL THEN
    RETURN pgsodium.crypto_shorthash(message, key.decrypted_raw_key);
  END IF;
  RETURN pgsodium.crypto_shorthash(message, key.key_id, key.key_context);
END;

$$;

alter function crypto_shorthash(bytea, uuid) owner to pgsodium_keymaker;

grant execute on function crypto_shorthash(bytea, uuid) to pgsodium_keyiduser;


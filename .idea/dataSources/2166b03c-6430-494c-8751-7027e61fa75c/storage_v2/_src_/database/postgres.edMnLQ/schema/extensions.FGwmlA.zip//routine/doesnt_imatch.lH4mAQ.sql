create function doesnt_imatch(anyelement, text) returns text
    language sql
as
$$
    SELECT _unalike( $1 !~* $2, $1, $2, NULL );
$$;

alter function doesnt_imatch(anyelement, text) owner to supabase_admin;

grant execute on function doesnt_imatch(anyelement, text) to postgres with grant option;


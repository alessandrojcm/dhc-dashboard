create function uninstall_extension_if_exists(extname text) returns boolean
    strict
    SET search_path = pgtle
    language plpgsql
as
$$
BEGIN
  PERFORM pgtle.uninstall_extension(extname);
  RETURN TRUE;
EXCEPTION
  WHEN no_data_found THEN
    RETURN FALSE;
END;
$$;

alter function uninstall_extension_if_exists(text) owner to supabase_admin;

grant execute on function uninstall_extension_if_exists(text) to pgtle_admin;


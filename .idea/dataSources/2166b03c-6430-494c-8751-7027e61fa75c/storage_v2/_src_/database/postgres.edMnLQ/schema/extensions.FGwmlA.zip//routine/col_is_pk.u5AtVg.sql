create function col_is_pk(name, name[], text) returns text
    language sql
as
$$
    SELECT is( _ckeys( $1, 'p' ), $2, $3 );
$$;

alter function col_is_pk(name, name[], text) owner to supabase_admin;

grant execute on function col_is_pk(name, name[], text) to postgres with grant option;


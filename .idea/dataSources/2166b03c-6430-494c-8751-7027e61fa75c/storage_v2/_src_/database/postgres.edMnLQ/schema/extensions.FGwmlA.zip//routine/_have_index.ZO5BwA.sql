create function _have_index(name, name, name) returns boolean
    language sql
as
$$
    SELECT EXISTS (
    SELECT TRUE
      FROM pg_catalog.pg_index x
      JOIN pg_catalog.pg_class ct    ON ct.oid = x.indrelid
      JOIN pg_catalog.pg_class ci    ON ci.oid = x.indexrelid
      JOIN pg_catalog.pg_namespace n ON n.oid = ct.relnamespace
     WHERE n.nspname  = $1
       AND ct.relname = $2
       AND ci.relname = $3
    );
$$;

alter function _have_index(name, name, name) owner to supabase_admin;

grant execute on function _have_index(name, name, name) to postgres with grant option;


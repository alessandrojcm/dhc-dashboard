create function crypto_sign_update_agg1(state bytea, message bytea) returns bytea
    immutable
    language sql
as
$$
 SELECT pgsodium.crypto_sign_update(COALESCE(state, pgsodium.crypto_sign_init()), message);
$$;

comment on function crypto_sign_update_agg1(bytea, bytea) is 'Internal helper function for crypto_sign_update_agg(bytea). This
initializes state if it has not already been initialized.';

alter function crypto_sign_update_agg1(bytea, bytea) owner to supabase_admin;

grant execute on function crypto_sign_update_agg1(bytea, bytea) to pgsodium_keyholder;


create function hasnt_role(name) returns text
    language sql
as
$$
    SELECT ok( NOT _has_role($1), 'Role ' || quote_ident($1) || ' should not exist' );
$$;

alter function hasnt_role(name) owner to supabase_admin;

grant execute on function hasnt_role(name) to postgres with grant option;


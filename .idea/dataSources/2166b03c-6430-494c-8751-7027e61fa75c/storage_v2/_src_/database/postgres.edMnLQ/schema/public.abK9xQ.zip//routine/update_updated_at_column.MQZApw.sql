create function update_updated_at_column(event jsonb) returns trigger
    SET search_path = ""
    language plpgsql
as
$$
begin
    new.updated_at = now();
    return new;
end;
$$;

alter function update_updated_at_column(jsonb) owner to postgres;

grant execute on function update_updated_at_column(jsonb) to anon;

grant execute on function update_updated_at_column(jsonb) to authenticated;

grant execute on function update_updated_at_column(jsonb) to service_role;


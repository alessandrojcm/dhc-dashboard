create function _extras(character, name[]) returns name[]
    language sql
as
$$
SELECT _extras(ARRAY[$1], $2);
$$;

alter function _extras(char, name[]) owner to supabase_admin;

grant execute on function _extras(char, name[]) to postgres with grant option;


create function throws_ok(text, integer) returns text
    language sql
as
$$
    SELECT throws_ok( $1, $2::char(5), NULL, NULL );
$$;

alter function throws_ok(text, integer) owner to supabase_admin;

grant execute on function throws_ok(text, integer) to postgres with grant option;


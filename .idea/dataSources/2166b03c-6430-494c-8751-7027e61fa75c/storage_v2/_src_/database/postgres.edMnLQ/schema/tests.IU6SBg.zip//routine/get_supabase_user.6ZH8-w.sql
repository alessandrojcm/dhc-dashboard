create function get_supabase_user(identifier text) returns json
    security definer
    SET search_path = auth, pg_temp
    language plpgsql
as
$$
    DECLARE
        supabase_user json;
    BEGIN
        SELECT json_build_object(
        'id', id,
        'email', email,
        'phone', phone,
        'raw_user_meta_data', raw_user_meta_data,
        'raw_app_meta_data', raw_app_meta_data
        ) into supabase_user
        FROM auth.users
        WHERE raw_user_meta_data ->> 'test_identifier' = identifier limit 1;
        
        if supabase_user is null OR supabase_user -> 'id' IS NULL then
            RAISE EXCEPTION 'User with identifier % not found', identifier;
        end if;
        RETURN supabase_user;
    END;
$$;

alter function get_supabase_user(text) owner to postgres;

grant execute on function get_supabase_user(text) to anon;

grant execute on function get_supabase_user(text) to authenticated;

grant execute on function get_supabase_user(text) to service_role;


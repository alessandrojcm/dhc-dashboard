create function _has_group(name) returns boolean
    strict
    language sql
as
$$
    SELECT EXISTS(
        SELECT true
          FROM pg_catalog.pg_group
         WHERE groname = $1
    );
$$;

alter function _has_group(name) owner to supabase_admin;

grant execute on function _has_group(name) to postgres with grant option;


create function register_feature_if_not_exists(proc regproc, feature pgtle.pg_tle_features) returns boolean
    language plpgsql
as
$$
BEGIN
  PERFORM pgtle.register_feature(proc, feature);
  RETURN TRUE;
EXCEPTION
  -- only catch the unique violation. let all other exceptions pass through.
  WHEN unique_violation THEN
    RETURN FALSE;
END;
$$;

alter function register_feature_if_not_exists(regproc, pgtle.pg_tle_features) owner to supabase_admin;

grant execute on function register_feature_if_not_exists(regproc, pgtle.pg_tle_features) to pgtle_admin;


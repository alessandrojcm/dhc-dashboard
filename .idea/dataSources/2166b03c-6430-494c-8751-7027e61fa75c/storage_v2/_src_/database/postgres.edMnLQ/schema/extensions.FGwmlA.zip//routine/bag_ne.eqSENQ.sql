create function bag_ne(text, anyarray, text) returns text
    language sql
as
$$
    SELECT _relne( $1, $2, $3, 'ALL ' );
$$;

alter function bag_ne(text, anyarray, text) owner to supabase_admin;

grant execute on function bag_ne(text, anyarray, text) to postgres with grant option;


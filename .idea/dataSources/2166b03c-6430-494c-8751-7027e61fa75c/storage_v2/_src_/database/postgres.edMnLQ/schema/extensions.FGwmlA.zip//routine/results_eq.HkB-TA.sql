create function results_eq(text, refcursor) returns text
    language sql
as
$$
    SELECT results_eq( $1, $2, NULL::text );
$$;

alter function results_eq(text, refcursor) owner to supabase_admin;

grant execute on function results_eq(text, refcursor) to postgres with grant option;


create function _pg_sv_column_array(oid, smallint[]) returns name[]
    stable
    language sql
as
$$
    SELECT ARRAY(
        SELECT a.attname
          FROM pg_catalog.pg_attribute a
          JOIN generate_series(1, array_upper($2, 1)) s(i) ON a.attnum = $2[i]
         WHERE attrelid = $1
         ORDER BY i
    )
$$;

alter function _pg_sv_column_array(oid, smallint[]) owner to supabase_admin;

grant execute on function _pg_sv_column_array(oid, smallint[]) to postgres with grant option;


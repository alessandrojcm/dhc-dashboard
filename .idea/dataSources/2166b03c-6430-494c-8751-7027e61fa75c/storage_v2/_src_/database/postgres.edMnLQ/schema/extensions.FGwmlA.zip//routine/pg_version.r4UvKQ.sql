create function pg_version() returns text
    immutable
    language sql
as
$$SELECT current_setting('server_version')$$;

alter function pg_version() owner to supabase_admin;

grant execute on function pg_version() to postgres with grant option;


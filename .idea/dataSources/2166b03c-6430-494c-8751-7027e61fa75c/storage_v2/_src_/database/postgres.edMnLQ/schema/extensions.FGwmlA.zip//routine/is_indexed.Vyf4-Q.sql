create function is_indexed(name, name, name[], text) returns text
    language sql
as
$$
   SELECT ok( _is_indexed($1, $2, $3), $4 );
$$;

alter function is_indexed(name, name, name[], text) owner to supabase_admin;

grant execute on function is_indexed(name, name, name[], text) to postgres with grant option;


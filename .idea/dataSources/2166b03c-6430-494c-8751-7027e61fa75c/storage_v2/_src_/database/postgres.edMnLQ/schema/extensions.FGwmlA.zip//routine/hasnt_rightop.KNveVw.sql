create function hasnt_rightop(name, name, name) returns text
    language sql
as
$$
    SELECT ok(
         NOT _op_exists($1, $2, NULL, $3 ),
        'Right operator ' || $2 || '('
        || $1 || ',NONE) RETURNS ' || $3 || ' should not exist'
    );
$$;

alter function hasnt_rightop(name, name, name) owner to supabase_admin;

grant execute on function hasnt_rightop(name, name, name) to postgres with grant option;


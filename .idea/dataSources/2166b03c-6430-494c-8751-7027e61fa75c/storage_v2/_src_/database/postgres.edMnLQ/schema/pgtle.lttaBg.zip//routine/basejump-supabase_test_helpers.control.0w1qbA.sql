create function "basejump-supabase_test_helpers.control"() returns text
    language sql
as
$$SELECT $_pgtle_i_$default_version = '0.0.6'
comment = 'A collection of functions designed to make testing Supabase projects easier'
relocatable = false
superuser = false
trusted = false
requires = 'pgtap,pg_tle'
$_pgtle_i_$$ $;

alter function "basejump-supabase_test_helpers.control"() owner to postgres;


create function hasnt_cast(name, name) returns text
    language sql
as
$$
    SELECT ok(
        NOT _cast_exists( $1, $2 ),
        'Cast (' || quote_ident($1) || ' AS ' || quote_ident($2)
        || ') should not exist'
    );
$$;

alter function hasnt_cast(name, name) owner to supabase_admin;

grant execute on function hasnt_cast(name, name) to postgres with grant option;


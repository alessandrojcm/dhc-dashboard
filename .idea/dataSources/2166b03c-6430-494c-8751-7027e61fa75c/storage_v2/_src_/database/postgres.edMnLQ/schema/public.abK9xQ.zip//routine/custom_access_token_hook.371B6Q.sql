create function custom_access_token_hook(event jsonb) returns jsonb
    language plpgsql
as
$$
declare
    claims           jsonb;
    user_roles       public.role_type[];
    is_valid         bool;
    hook_instance_id uuid;
begin
    hook_instance_id := gen_random_uuid();
    -- Create one instance ID for the entire hook execution

    -- Log the start of hook execution
    insert into auth.audit_log_entries (instance_id,
                                        id,
                                        payload)
    values (hook_instance_id,
            gen_random_uuid(),
            jsonb_build_object(
                    'event', event,
                    'step', 'auth_hook_start'
            ));

    -- Check if user_id exists in the event
    if event ->> 'user_id' is null then
        insert into auth.audit_log_entries (instance_id,
                                            id,
                                            payload)
        values (hook_instance_id,
                gen_random_uuid(),
                jsonb_build_object(
                        'event', event,
                        'error', 'No user_id in event',
                        'step', 'auth_hook_error'
                ));

        return jsonb_build_object(
                'error', jsonb_build_object(
                        'http_code', 403,
                        'message', 'Invalid token data'
                         )
               );
    end if;

    -- Check user existence
    begin
        select exists (select 1
                       from public.user_profiles
                       where id = (event ->> 'user_id')::uuid)
        into is_valid;
    exception
        when others then
            insert into auth.audit_log_entries (instance_id,
                                                id,
                                                payload)
            values (hook_instance_id,
                    gen_random_uuid(),
                    jsonb_build_object(
                            'event', event,
                            'error', SQLERRM,
                            'step', 'auth_hook_error',
                            'detail', 'user_check_failed'
                    ));

            return jsonb_build_object(
                    'error', jsonb_build_object(
                            'http_code', 403,
                            'message', 'Error validating user'
                             )
                   );
    end;

    if not is_valid then
        insert into auth.audit_log_entries (instance_id,
                                            id,
                                            payload)
        values (hook_instance_id,
                gen_random_uuid(),
                jsonb_build_object(
                        'event', event,
                        'error', 'User not found in profiles',
                        'step', 'auth_hook_error',
                        'detail', 'user_not_found'
                ));

        return jsonb_build_object(
                'error', jsonb_build_object(
                        'http_code', 403,
                        'message', 'User not registered in the system'
                         )
               );
    end if;

    -- Get user roles
    begin
        select array_agg(role)
        into user_roles
        from public.user_roles
        where user_id = (event ->> 'user_id')::uuid;

        insert into auth.audit_log_entries (instance_id,
                                            id,
                                            payload)
        values (hook_instance_id,
                gen_random_uuid(),
                jsonb_build_object(
                        'event', event,
                        'roles', user_roles,
                        'step', 'auth_hook_info',
                        'detail', 'roles_fetched'
                ));
    exception
        when others then
            insert into auth.audit_log_entries (instance_id,
                                                id,
                                                payload)
            values (hook_instance_id,
                    gen_random_uuid(),
                    jsonb_build_object(
                            'event', event,
                            'error', SQLERRM,
                            'step', 'auth_hook_error',
                            'detail', 'roles_fetch_failed'
                    ));

            return jsonb_build_object(
                    'error', jsonb_build_object(
                            'http_code', 403,
                            'message', 'Error fetching user roles'
                             )
                   );
    end;

    -- Handle claims
    begin
        claims := event -> 'claims';
        if claims is null then
            claims := '{}'::jsonb;
        end if;

        -- Ensure app_metadata exists
        if not claims ? 'app_metadata' then
            claims := jsonb_set(claims, '{app_metadata}', '{}'::jsonb);
        end if;

        -- Add roles to claims
        claims := jsonb_set(
                claims,
                '{app_metadata,roles}',
                coalesce(to_jsonb(user_roles), '[]'::jsonb)
                  );

        -- Update final event
        event := jsonb_set(event, '{claims}', claims);

        insert into auth.audit_log_entries (instance_id,
                                            id,
                                            payload)
        values (hook_instance_id,
                gen_random_uuid(),
                jsonb_build_object(
                        'event', event,
                        'final_claims', claims,
                        'step', 'auth_hook_success'
                ));

        return event;
    exception
        when others then
            insert into auth.audit_log_entries (instance_id,
                                                id,
                                                payload)
            values (hook_instance_id,
                    gen_random_uuid(),
                    jsonb_build_object(
                            'event', event,
                            'error', SQLERRM,
                            'step', 'auth_hook_error',
                            'detail', 'claims_processing_failed'
                    ));

            return jsonb_build_object(
                    'error', jsonb_build_object(
                            'http_code', 403,
                            'message', 'Error processing claims'
                             )
                   );
    end;
end;
$$;

alter function custom_access_token_hook(jsonb) owner to postgres;

grant execute on function custom_access_token_hook(jsonb) to service_role;

grant execute on function custom_access_token_hook(jsonb) to supabase_auth_admin;


create function hasnt_rightop(name, name) returns text
    language sql
as
$$
    SELECT ok(
         NOT _op_exists($1, $2, NULL ),
        'Right operator ' || $2 || '(' || $1 || ',NONE) should not exist'
    );
$$;

alter function hasnt_rightop(name, name) owner to supabase_admin;

grant execute on function hasnt_rightop(name, name) to postgres with grant option;


create function matches(anyelement, text) returns text
    language sql
as
$$
    SELECT _alike( $1 ~ $2, $1, $2, NULL );
$$;

alter function matches(anyelement, text) owner to supabase_admin;

grant execute on function matches(anyelement, text) to postgres with grant option;


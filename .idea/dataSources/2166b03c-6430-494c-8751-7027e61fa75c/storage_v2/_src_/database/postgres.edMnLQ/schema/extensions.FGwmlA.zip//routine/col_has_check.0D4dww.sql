create function col_has_check(name, name, text) returns text
    language sql
as
$$
    SELECT col_has_check( $1, ARRAY[$2], $3 );
$$;

alter function col_has_check(name, name, text) owner to supabase_admin;

grant execute on function col_has_check(name, name, text) to postgres with grant option;


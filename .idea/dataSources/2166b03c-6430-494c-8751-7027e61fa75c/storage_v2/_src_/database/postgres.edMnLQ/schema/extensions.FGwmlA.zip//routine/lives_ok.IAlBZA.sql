create function lives_ok(text) returns text
    language sql
as
$$
    SELECT lives_ok( $1, NULL );
$$;

alter function lives_ok(text) owner to supabase_admin;

grant execute on function lives_ok(text) to postgres with grant option;


create function throws_ok(text) returns text
    language sql
as
$$
    SELECT throws_ok( $1, NULL, NULL, NULL );
$$;

alter function throws_ok(text) owner to supabase_admin;

grant execute on function throws_ok(text) to postgres with grant option;


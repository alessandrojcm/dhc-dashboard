create function trigger_is(name, name, name, name, name) returns text
    language sql
as
$$
    SELECT trigger_is(
        $1, $2, $3, $4, $5,
        'Trigger ' || quote_ident($3) || ' should call ' || quote_ident($4) || '.' || quote_ident($5) || '()'
    );
$$;

alter function trigger_is(name, name, name, name, name) owner to supabase_admin;

grant execute on function trigger_is(name, name, name, name, name) to postgres with grant option;


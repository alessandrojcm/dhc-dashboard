create function can_insert_object(bucketid text, name text, owner uuid, metadata jsonb) returns void
    language plpgsql
as
$$
BEGIN
  INSERT INTO "storage"."objects" ("bucket_id", "name", "owner", "metadata") VALUES (bucketid, name, owner, metadata);
  -- hack to rollback the successful insert
  RAISE sqlstate 'PT200' using
  message = 'ROLLBACK',
  detail = 'rollback successful insert';
END
$$;

alter function can_insert_object(text, text, uuid, jsonb) owner to supabase_storage_admin;


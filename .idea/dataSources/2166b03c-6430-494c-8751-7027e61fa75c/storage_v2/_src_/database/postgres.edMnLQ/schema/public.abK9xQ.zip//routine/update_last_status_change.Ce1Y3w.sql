create function update_last_status_change() returns trigger
    SET search_path = ""
    language plpgsql
as
$$
begin
    if OLD.status != NEW.status then
        NEW.last_status_change := current_timestamp;
    end if;
    return NEW;
end;
$$;

alter function update_last_status_change() owner to postgres;

grant execute on function update_last_status_change() to anon;

grant execute on function update_last_status_change() to authenticated;

grant execute on function update_last_status_change() to service_role;


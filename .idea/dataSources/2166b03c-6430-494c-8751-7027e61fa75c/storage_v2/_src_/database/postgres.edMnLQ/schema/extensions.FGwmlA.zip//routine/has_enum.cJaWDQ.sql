create function has_enum(name) returns text
    language sql
as
$$
    SELECT ok( _has_type( $1, ARRAY['e'] ), ('Enum ' || quote_ident($1) || ' should exist')::text );
$$;

alter function has_enum(name) owner to supabase_admin;

grant execute on function has_enum(name) to postgres with grant option;


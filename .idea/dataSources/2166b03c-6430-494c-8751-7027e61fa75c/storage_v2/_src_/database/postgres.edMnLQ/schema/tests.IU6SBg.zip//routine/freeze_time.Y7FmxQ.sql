create function freeze_time(frozen_time timestamp with time zone) returns void
    language plpgsql
as
$$
BEGIN

    -- Add test_overrides to search path if needed
    IF current_setting('search_path') NOT LIKE 'test_overrides,%' THEN
        -- store search path for later
        PERFORM set_config('tests.original_search_path', current_setting('search_path'), true);
        
        -- add tests schema to start of search path
        PERFORM set_config('search_path', 'test_overrides,' || current_setting('tests.original_search_path') || ',pg_catalog', true);
    END IF;

    -- create an overwriting now function
    PERFORM set_config('tests.frozen_time', frozen_time::text, true);

END
$$;

alter function freeze_time(timestamp with time zone) owner to postgres;

grant execute on function freeze_time(timestamp with time zone) to anon;

grant execute on function freeze_time(timestamp with time zone) to authenticated;

grant execute on function freeze_time(timestamp with time zone) to service_role;


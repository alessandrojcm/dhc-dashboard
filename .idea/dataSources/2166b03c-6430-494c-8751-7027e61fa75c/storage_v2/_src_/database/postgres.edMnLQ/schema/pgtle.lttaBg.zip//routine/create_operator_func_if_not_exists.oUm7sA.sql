create function create_operator_func_if_not_exists(typenamespace regnamespace, typename name, opfunc regprocedure) returns boolean
    strict
    SET search_path = pgtle
    language plpgsql
as
$$
BEGIN
  PERFORM pgtle.create_operator_func(typenamespace, typename, opfunc);
  RETURN TRUE;
EXCEPTION
  -- only catch the duplicate_object exception, let all other exceptions pass through.
  WHEN duplicate_object THEN
    RETURN FALSE;
END;
$$;

alter function create_operator_func_if_not_exists(regnamespace, name, regprocedure) owner to supabase_admin;

grant execute on function create_operator_func_if_not_exists(regnamespace, name, regprocedure) to pgtle_admin;


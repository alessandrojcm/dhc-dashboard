create function "supabase-dbdev.control"() returns text
    language sql
as
$$SELECT $_pgtle_i_$default_version = '0.0.5'
comment = 'PostgreSQL package manager'
relocatable = false
superuser = false
trusted = false
requires = 'pg_tle'
$_pgtle_i_$$ $;

alter function "supabase-dbdev.control"() owner to postgres;


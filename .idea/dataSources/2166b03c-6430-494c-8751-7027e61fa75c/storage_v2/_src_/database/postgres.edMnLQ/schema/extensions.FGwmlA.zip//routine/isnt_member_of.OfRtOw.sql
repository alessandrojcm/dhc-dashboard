create function isnt_member_of(name, name, text) returns text
    language sql
as
$$
    SELECT isnt_member_of( $1, ARRAY[$2], $3 );
$$;

alter function isnt_member_of(name, name, text) owner to supabase_admin;

grant execute on function isnt_member_of(name, name, text) to postgres with grant option;


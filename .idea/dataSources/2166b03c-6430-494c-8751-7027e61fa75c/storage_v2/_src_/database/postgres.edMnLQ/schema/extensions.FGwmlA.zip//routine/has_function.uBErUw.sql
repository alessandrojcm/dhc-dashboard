create function has_function(name, name) returns text
    language sql
as
$$
    SELECT ok(
        _got_func($1, $2),
        'Function ' || quote_ident($1) || '.' || quote_ident($2) || '() should exist'
    );
$$;

alter function has_function(name, name) owner to supabase_admin;

grant execute on function has_function(name, name) to postgres with grant option;


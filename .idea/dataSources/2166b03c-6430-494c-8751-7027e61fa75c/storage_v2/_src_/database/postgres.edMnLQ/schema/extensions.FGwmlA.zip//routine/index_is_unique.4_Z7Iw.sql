create function index_is_unique(name, name, name) returns text
    language sql
as
$$
    SELECT index_is_unique(
        $1, $2, $3,
        'Index ' || quote_ident($3) || ' should be unique'
    );
$$;

alter function index_is_unique(name, name, name) owner to supabase_admin;

grant execute on function index_is_unique(name, name, name) to postgres with grant option;


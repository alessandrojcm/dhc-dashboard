create function _pg_sv_table_accessible(oid, oid) returns boolean
    immutable
    strict
    language sql
as
$$
    SELECT CASE WHEN has_schema_privilege($1, 'USAGE') THEN (
                  has_table_privilege($2, 'SELECT')
               OR has_table_privilege($2, 'INSERT')
               or has_table_privilege($2, 'UPDATE')
               OR has_table_privilege($2, 'DELETE')
               OR has_table_privilege($2, 'RULE')
               OR has_table_privilege($2, 'REFERENCES')
               OR has_table_privilege($2, 'TRIGGER')
           ) ELSE FALSE
    END;
$$;

alter function _pg_sv_table_accessible(oid, oid) owner to supabase_admin;

grant execute on function _pg_sv_table_accessible(oid, oid) to postgres with grant option;


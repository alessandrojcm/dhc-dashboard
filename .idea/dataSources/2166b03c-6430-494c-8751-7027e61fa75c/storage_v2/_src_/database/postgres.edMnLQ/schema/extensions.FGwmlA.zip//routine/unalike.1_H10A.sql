create function unalike(anyelement, text) returns text
    language sql
as
$$
    SELECT _unalike( $1 !~~ $2, $1, $2, NULL );
$$;

alter function unalike(anyelement, text) owner to supabase_admin;

grant execute on function unalike(anyelement, text) to postgres with grant option;


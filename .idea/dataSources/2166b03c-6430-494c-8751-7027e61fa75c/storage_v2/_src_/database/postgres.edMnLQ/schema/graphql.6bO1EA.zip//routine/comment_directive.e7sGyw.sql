create function comment_directive(comment_ text) returns jsonb
    immutable
    language sql
as
$$
    /*
    comment on column public.account.name is '@graphql.name: myField'
    */
    select
        coalesce(
            (
                regexp_match(
                    comment_,
                    '@graphql\((.+?)\)'
                )
            )[1]::jsonb,
            jsonb_build_object()
        )
$$;

alter function comment_directive(text) owner to supabase_admin;

grant execute on function comment_directive(text) to postgres;

grant execute on function comment_directive(text) to anon;

grant execute on function comment_directive(text) to authenticated;

grant execute on function comment_directive(text) to service_role;


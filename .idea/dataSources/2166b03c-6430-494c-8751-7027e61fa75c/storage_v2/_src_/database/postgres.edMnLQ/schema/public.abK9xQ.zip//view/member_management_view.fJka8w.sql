create view member_management_view
            (id, user_profile_id, next_of_kin_name, next_of_kin_phone, preferred_weapon, membership_start_date,
             membership_end_date, last_payment_date, additional_data, created_at, updated_at, first_name, last_name,
             phone_number, gender, pronouns, is_active, email, from_waitlist_id, waitlist_registration_date, roles)
as
WITH current_user_id AS (SELECT auth.uid() AS uid)
SELECT mp.id,
       mp.user_profile_id,
       mp.next_of_kin_name,
       mp.next_of_kin_phone,
       mp.preferred_weapon,
       mp.membership_start_date,
       mp.membership_end_date,
       mp.last_payment_date,
       mp.additional_data,
       mp.created_at,
       mp.updated_at,
       up.first_name,
       up.last_name,
       up.phone_number,
       up.gender,
       up.pronouns,
       up.is_active,
       au.email,
       w.id                        AS from_waitlist_id,
       w.initial_registration_date AS waitlist_registration_date,
       array_agg(ur.role)          AS roles
FROM member_profiles mp
         JOIN user_profiles up ON mp.user_profile_id = up.id
         JOIN auth.users au ON up.supabase_user_id = au.id
         LEFT JOIN waitlist w ON up.waitlist_id = w.id
         LEFT JOIN user_roles ur ON up.supabase_user_id = ur.user_id
GROUP BY mp.id, up.id, au.id, w.id;

alter table member_management_view
    owner to postgres;

grant delete, insert, references, select, trigger, truncate, update on member_management_view to anon;

grant delete, insert, references, select, trigger, truncate, update on member_management_view to authenticated;

grant delete, insert, references, select, trigger, truncate, update on member_management_view to service_role;


create function _set(text, integer) returns integer
    language sql
as
$$
    SELECT _set($1, $2, '')
$$;

alter function _set(text, integer) owner to supabase_admin;

grant execute on function _set(text, integer) to postgres with grant option;


create function resolve(query text, variables jsonb DEFAULT '{}'::jsonb, "operationName" text DEFAULT NULL::text, extensions jsonb DEFAULT NULL::jsonb) returns jsonb
    language plpgsql
as
$$
declare
    res jsonb;
    message_text text;
begin
  begin
    select graphql._internal_resolve("query" := "query",
                                     "variables" := "variables",
                                     "operationName" := "operationName",
                                     "extensions" := "extensions") into res;
    return res;
  exception
    when others then
    get stacked diagnostics message_text = message_text;
    return
    jsonb_build_object('data', null,
                       'errors', jsonb_build_array(jsonb_build_object('message', message_text)));
  end;
end;
$$;

alter function resolve(text, jsonb, text, jsonb) owner to supabase_admin;

grant execute on function resolve(text, jsonb, text, jsonb) to postgres;

grant execute on function resolve(text, jsonb, text, jsonb) to anon;

grant execute on function resolve(text, jsonb, text, jsonb) to authenticated;

grant execute on function resolve(text, jsonb, text, jsonb) to service_role;


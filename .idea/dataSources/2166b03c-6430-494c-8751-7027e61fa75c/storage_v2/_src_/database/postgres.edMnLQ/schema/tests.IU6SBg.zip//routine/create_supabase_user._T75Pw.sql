create function create_supabase_user(identifier text, email text DEFAULT NULL::text, phone text DEFAULT NULL::text, metadata jsonb DEFAULT NULL::jsonb) returns uuid
    security definer
    SET search_path = auth, pg_temp
    language plpgsql
as
$$
DECLARE
    user_id uuid;
BEGIN

    -- create the user
    user_id := extensions.uuid_generate_v4();
    INSERT INTO auth.users (id, email, phone, raw_user_meta_data, raw_app_meta_data, created_at, updated_at)
    VALUES (user_id, coalesce(email, concat(user_id, '@test.com')), phone, jsonb_build_object('test_identifier', identifier) || coalesce(metadata, '{}'::jsonb), '{}'::jsonb, now(), now())
    RETURNING id INTO user_id;

    RETURN user_id;
END;
$$;

alter function create_supabase_user(text, text, text, jsonb) owner to postgres;

grant execute on function create_supabase_user(text, text, text, jsonb) to anon;

grant execute on function create_supabase_user(text, text, text, jsonb) to authenticated;

grant execute on function create_supabase_user(text, text, text, jsonb) to service_role;


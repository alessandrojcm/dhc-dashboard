create function has_trigger(name, name, name, text) returns text
    language sql
as
$$
    SELECT ok( _trig($1, $2, $3), $4);
$$;

alter function has_trigger(name, name, name, text) owner to supabase_admin;

grant execute on function has_trigger(name, name, name, text) to postgres with grant option;


create function _funkargs(name[]) returns text
    stable
    language plpgsql
as
$$
BEGIN
    RETURN array_to_string($1::regtype[], ',');
EXCEPTION WHEN undefined_object THEN
    RETURN array_to_string($1, ',');
END;
$$;

alter function _funkargs(name[]) owner to supabase_admin;

grant execute on function _funkargs(name[]) to postgres with grant option;


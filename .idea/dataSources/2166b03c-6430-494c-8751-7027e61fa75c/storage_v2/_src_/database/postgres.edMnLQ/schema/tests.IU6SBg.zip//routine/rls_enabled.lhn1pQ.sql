create function rls_enabled(testing_schema text, testing_table text) returns text
    language sql
as
$$
    select is(
        (select
           	count(*)::integer
           from pg_class pc
           join pg_namespace pn on pn.oid = pc.relnamespace and pn.nspname = rls_enabled.testing_schema and pc.relname = rls_enabled.testing_table
           join pg_type pt on pt.oid = pc.reltype
           where relrowsecurity = TRUE),
        1,
        testing_table || 'table in the' || testing_schema || ' schema should have row level security enabled'
    );
$$;

alter function rls_enabled(text, text) owner to postgres;

grant execute on function rls_enabled(text, text) to anon;

grant execute on function rls_enabled(text, text) to authenticated;

grant execute on function rls_enabled(text, text) to service_role;


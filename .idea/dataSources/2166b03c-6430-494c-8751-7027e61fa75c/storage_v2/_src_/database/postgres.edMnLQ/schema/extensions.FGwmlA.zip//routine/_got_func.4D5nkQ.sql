create function _got_func(name) returns boolean
    language sql
as
$$
    SELECT EXISTS( SELECT TRUE FROM tap_funky WHERE name = $1 AND is_visible);
$$;

alter function _got_func(name) owner to supabase_admin;

grant execute on function _got_func(name) to postgres with grant option;


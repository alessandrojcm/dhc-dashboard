create view waitlist_management_view
            (id, email, medical_conditions, insurance_form_submitted, status, initial_registration_date,
             last_status_change, last_contacted, admin_notes, search_text, phone_number, full_name, current_position,
             age)
as
SELECT w.id,
       w.email,
       w.medical_conditions,
       w.insurance_form_submitted,
       w.status,
       w.initial_registration_date,
       w.last_status_change,
       w.last_contacted,
       w.admin_notes,
       u.search_text,
       u.phone_number,
       concat(u.first_name, ' ', u.last_name)                            AS full_name,
       get_waitlist_position(w.id)                                       AS current_position,
       EXTRACT(year FROM age(u.date_of_birth::timestamp with time zone)) AS age
FROM user_profiles u
         JOIN waitlist w ON u.waitlist_id = w.id
WHERE u.waitlist_id IS NOT NULL;

alter table waitlist_management_view
    owner to postgres;

grant delete, insert, references, select, trigger, truncate, update on waitlist_management_view to anon;

grant delete, insert, references, select, trigger, truncate, update on waitlist_management_view to authenticated;

grant delete, insert, references, select, trigger, truncate, update on waitlist_management_view to service_role;


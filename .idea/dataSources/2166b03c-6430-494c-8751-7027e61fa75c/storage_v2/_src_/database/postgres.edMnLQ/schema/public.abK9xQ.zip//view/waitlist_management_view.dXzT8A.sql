create view waitlist_management_view
            (id, first_name, last_name, email, phone_number, date_of_birth, medical_conditions,
             insurance_form_submitted, status, initial_registration_date, last_status_change, last_contacted,
             admin_notes, search_text, gender, pronouns, full_name, current_position, age)
as
SELECT w.id,
       w.first_name,
       w.last_name,
       w.email,
       w.phone_number,
       w.date_of_birth,
       w.medical_conditions,
       w.insurance_form_submitted,
       w.status,
       w.initial_registration_date,
       w.last_status_change,
       w.last_contacted,
       w.admin_notes,
       w.search_text,
       w.gender,
       w.pronouns,
       concat(w.first_name, ' ', w.last_name)                            AS full_name,
       get_waitlist_position(w.id)                                       AS current_position,
       EXTRACT(year FROM age(w.date_of_birth::timestamp with time zone)) AS age
FROM waitlist w;

alter table waitlist_management_view
    owner to postgres;

grant delete, insert, references, select, trigger, truncate, update on waitlist_management_view to anon;

grant delete, insert, references, select, trigger, truncate, update on waitlist_management_view to authenticated;

grant delete, insert, references, select, trigger, truncate, update on waitlist_management_view to service_role;


create function update_masks(debug boolean DEFAULT false) returns void
    SET search_path = ""
    language plpgsql
as
$$
BEGIN
  PERFORM pgsodium.update_mask(objoid, debug)
    FROM pg_catalog.pg_seclabel sl
    JOIN pg_catalog.pg_class cl ON (cl.oid = sl.objoid)
    WHERE label ilike 'ENCRYPT%'
       AND cl.relowner = session_user::regrole::oid
       AND provider = 'pgsodium'
	   AND objoid::regclass != 'pgsodium.key'::regclass
	;
  RETURN;
END
$$;

alter function update_masks(boolean) owner to supabase_admin;


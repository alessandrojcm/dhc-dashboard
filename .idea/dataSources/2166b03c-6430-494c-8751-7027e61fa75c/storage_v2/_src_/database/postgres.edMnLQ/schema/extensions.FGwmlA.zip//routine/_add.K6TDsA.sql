create function _add(text, integer, text) returns integer
    language plpgsql
as
$$
BEGIN
    EXECUTE 'INSERT INTO __tcache__ (label, value, note) values (' ||
    quote_literal($1) || ', ' || $2 || ', ' || quote_literal(COALESCE($3, '')) || ')';
    RETURN $2;
END;
$$;

alter function _add(text, integer, text) owner to supabase_admin;

grant execute on function _add(text, integer, text) to postgres with grant option;


create function in_todo() returns boolean
    language plpgsql
as
$$
DECLARE
    todos integer;
BEGIN
    todos := _get('todo');
    RETURN CASE WHEN todos IS NULL THEN FALSE ELSE TRUE END;
END;
$$;

alter function in_todo() owner to supabase_admin;

grant execute on function in_todo() to postgres with grant option;


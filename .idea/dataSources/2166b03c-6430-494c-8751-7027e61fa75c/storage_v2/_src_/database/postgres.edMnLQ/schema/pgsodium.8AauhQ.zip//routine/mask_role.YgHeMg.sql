create function mask_role(masked_role regrole, source_name text, view_name text) returns void
    security definer
    SET search_path = pg_catalog
    language plpgsql
as
$$
BEGIN
  EXECUTE format(
    'GRANT SELECT ON pgsodium.key TO %s',
    masked_role);

  EXECUTE format(
    'GRANT pgsodium_keyiduser, pgsodium_keyholder TO %s',
    masked_role);

  EXECUTE format(
    'GRANT ALL ON %s TO %s',
    view_name,
    masked_role);
  RETURN;
END
$$;

alter function mask_role(regrole, text, text) owner to supabase_admin;


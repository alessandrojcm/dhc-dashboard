create function has_role(name, text) returns text
    language sql
as
$$
    SELECT ok( _has_role($1), $2 );
$$;

alter function has_role(name, text) owner to supabase_admin;

grant execute on function has_role(name, text) to postgres with grant option;


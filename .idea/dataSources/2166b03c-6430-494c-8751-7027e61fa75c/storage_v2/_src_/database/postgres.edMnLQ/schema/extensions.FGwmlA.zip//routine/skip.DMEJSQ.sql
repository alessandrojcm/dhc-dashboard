create function skip(integer) returns text
    language sql
as
$$SELECT skip(NULL, $1)$$;

alter function skip(integer) owner to supabase_admin;

grant execute on function skip(integer) to postgres with grant option;


create function has_composite(name, name, text) returns text
    language sql
as
$$
    SELECT ok( _rexists( 'c', $1, $2 ), $3 );
$$;

alter function has_composite(name, name, text) owner to supabase_admin;

grant execute on function has_composite(name, name, text) to postgres with grant option;


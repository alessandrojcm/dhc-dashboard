create function isnt(anyelement, anyelement) returns text
    language sql
as
$$
    SELECT isnt( $1, $2, NULL);
$$;

alter function isnt(anyelement, anyelement) owner to supabase_admin;

grant execute on function isnt(anyelement, anyelement) to postgres with grant option;


create function todo_start() returns SETOF boolean
    language plpgsql
as
$$
BEGIN
    PERFORM _add('todo', -1, '');
    RETURN;
END;
$$;

alter function todo_start() owner to supabase_admin;

grant execute on function todo_start() to postgres with grant option;


create function pg_version_num() returns integer
    immutable
    language sql
as
$$
    SELECT current_setting('server_version_num')::integer;
$$;

alter function pg_version_num() owner to supabase_admin;

grant execute on function pg_version_num() to postgres with grant option;


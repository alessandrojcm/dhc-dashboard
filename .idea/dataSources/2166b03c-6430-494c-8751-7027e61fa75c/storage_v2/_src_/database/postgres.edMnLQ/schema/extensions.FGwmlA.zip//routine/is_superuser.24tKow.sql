create function is_superuser(name) returns text
    language sql
as
$$
    SELECT is_superuser( $1, 'User ' || quote_ident($1) || ' should be a super user' );
$$;

alter function is_superuser(name) owner to supabase_admin;

grant execute on function is_superuser(name) to postgres with grant option;


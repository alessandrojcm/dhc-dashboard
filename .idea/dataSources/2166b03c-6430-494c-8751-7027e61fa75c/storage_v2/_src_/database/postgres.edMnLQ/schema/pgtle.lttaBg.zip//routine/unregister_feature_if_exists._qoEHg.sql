create function unregister_feature_if_exists(proc regproc, feature pgtle.pg_tle_features) returns boolean
    language plpgsql
as
$$
BEGIN
  PERFORM pgtle.unregister_feature(proc, feature);
  RETURN TRUE;
EXCEPTION
  -- only catch the error that no data was found
  WHEN no_data_found THEN
    RETURN FALSE;
END;
$$;

alter function unregister_feature_if_exists(regproc, pgtle.pg_tle_features) owner to supabase_admin;

grant execute on function unregister_feature_if_exists(regproc, pgtle.pg_tle_features) to pgtle_admin;


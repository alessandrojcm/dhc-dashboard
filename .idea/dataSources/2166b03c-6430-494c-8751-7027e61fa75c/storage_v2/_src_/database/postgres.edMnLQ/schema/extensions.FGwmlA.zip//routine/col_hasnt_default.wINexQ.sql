create function col_hasnt_default(name, name, name, text) returns text
    language plpgsql
as
$$
BEGIN
    IF NOT _cexists( $1, $2, $3 ) THEN
        RETURN fail( $4 ) || E'\n'
            || diag ('    Column ' || quote_ident($1) || '.' || quote_ident($2) || '.' || quote_ident($3) || ' does not exist' );
    END IF;
    RETURN ok( NOT _has_def( $1, $2, $3 ), $4 );
END;
$$;

alter function col_hasnt_default(name, name, name, text) owner to supabase_admin;

grant execute on function col_hasnt_default(name, name, name, text) to postgres with grant option;


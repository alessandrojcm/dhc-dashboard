create function _has_type(name, character[]) returns boolean
    language sql
as
$$
    SELECT EXISTS(
        SELECT true
          FROM pg_catalog.pg_type t
         WHERE t.typisdefined
           AND pg_catalog.pg_type_is_visible(t.oid)
           AND t.typname = $1
           AND t.typtype = ANY( COALESCE($2, ARRAY['b', 'c', 'd', 'p', 'e']) )
    );
$$;

alter function _has_type(name, character[]) owner to supabase_admin;

grant execute on function _has_type(name, character[]) to postgres with grant option;


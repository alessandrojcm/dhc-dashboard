create function update_secret(secret_id uuid, new_secret text DEFAULT NULL::text, new_name text DEFAULT NULL::text, new_description text DEFAULT NULL::text, new_key_id uuid DEFAULT NULL::uuid) returns void
    language sql
as
$$
	UPDATE vault.decrypted_secrets s
    SET
        secret = CASE WHEN new_secret IS NULL THEN s.decrypted_secret ELSE new_secret END,
        name = CASE WHEN new_name IS NULL THEN s.name ELSE new_name END,
        description = CASE WHEN new_description IS NULL THEN s.description ELSE new_description END,
        key_id = CASE WHEN new_key_id IS NULL THEN s.key_id ELSE new_key_id END,
        updated_at = CURRENT_TIMESTAMP
    WHERE s.id = secret_id
    $$;

alter function update_secret(uuid, text, text, text, uuid) owner to supabase_admin;


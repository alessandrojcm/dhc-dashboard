create function http_collect_response(request_id bigint, async boolean DEFAULT true) returns net.http_response_result
    strict
    parallel safe
    language plpgsql
as
$$
begin
  raise notice 'The net.http_collect_response function is deprecated.';
  select net._http_collect_response(request_id, async);
end;
$$;

alter function http_collect_response(bigint, boolean) owner to supabase_admin;


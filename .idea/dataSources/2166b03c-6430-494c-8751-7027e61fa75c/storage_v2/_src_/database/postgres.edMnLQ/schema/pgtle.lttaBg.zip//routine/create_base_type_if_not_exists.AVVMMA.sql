create function create_base_type_if_not_exists(typenamespace regnamespace, typename name, infunc regprocedure, outfunc regprocedure, internallength integer, alignment text DEFAULT 'int4'::text, storage text DEFAULT 'plain'::text) returns boolean
    strict
    SET search_path = pgtle
    language plpgsql
as
$$
BEGIN
  PERFORM pgtle.create_base_type(typenamespace, typename, infunc, outfunc, internallength, alignment, storage);
  RETURN TRUE;
EXCEPTION
  -- only catch the duplicate_object exception, let all other exceptions pass through.
  WHEN duplicate_object THEN
    RETURN FALSE;
END;
$$;

alter function create_base_type_if_not_exists(regnamespace, name, regprocedure, regprocedure, integer, text, text) owner to supabase_admin;

grant execute on function create_base_type_if_not_exists(regnamespace, name, regprocedure, regprocedure, integer, text, text) to pgtle_admin;


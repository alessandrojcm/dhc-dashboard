create function rls_enabled(testing_schema text) returns text
    language sql
as
$$
    select is(
        (select
           	count(pc.relname)::integer
           from pg_class pc
           join pg_namespace pn on pn.oid = pc.relnamespace and pn.nspname = rls_enabled.testing_schema
           join pg_type pt on pt.oid = pc.reltype
           where relrowsecurity = FALSE)
        ,
        0,
        'All tables in the' || testing_schema || ' schema should have row level security enabled');
$$;

alter function rls_enabled(text) owner to postgres;

grant execute on function rls_enabled(text) to anon;

grant execute on function rls_enabled(text) to authenticated;

grant execute on function rls_enabled(text) to service_role;


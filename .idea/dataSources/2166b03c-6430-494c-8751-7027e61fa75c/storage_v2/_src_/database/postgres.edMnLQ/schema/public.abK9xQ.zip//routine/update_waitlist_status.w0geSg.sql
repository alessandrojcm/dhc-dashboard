create function update_waitlist_status(p_waitlist_id uuid, p_new_status waitlist_status, p_notes text DEFAULT NULL::text) returns void
    SET search_path = ""
    language plpgsql
as
$$
declare
    v_old_status public.waitlist_status;
begin
    -- Get current status
    select status
    into v_old_status
    from public.waitlist
    where id = p_waitlist_id;

    -- Update status and last_status_change
    update public.waitlist
    set status             = p_new_status,
        last_status_change = now()
    where id = p_waitlist_id;

    -- Record in history
    insert into waitlist_status_history
        (waitlist_id, old_status, new_status, changed_by, notes)
    values (p_waitlist_id, v_old_status, p_new_status, auth.uid(), p_notes);
end;
$$;

alter function update_waitlist_status(uuid, waitlist_status, text) owner to postgres;

grant execute on function update_waitlist_status(uuid, waitlist_status, text) to anon;

grant execute on function update_waitlist_status(uuid, waitlist_status, text) to authenticated;

grant execute on function update_waitlist_status(uuid, waitlist_status, text) to service_role;


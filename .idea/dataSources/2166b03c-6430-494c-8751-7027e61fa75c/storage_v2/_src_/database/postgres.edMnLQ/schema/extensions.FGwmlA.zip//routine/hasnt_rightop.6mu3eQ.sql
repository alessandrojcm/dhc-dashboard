create function hasnt_rightop(name, name, name, name, text) returns text
    language sql
as
$$
    SELECT ok( NOT _op_exists( $1, $2, $3, NULL, $4), $5 );
$$;

alter function hasnt_rightop(name, name, name, name, text) owner to supabase_admin;

grant execute on function hasnt_rightop(name, name, name, name, text) to postgres with grant option;


create function _keys(name, name, character) returns SETOF name[]
    language sql
as
$$
    SELECT _pg_sv_column_array(x.conrelid,x.conkey) -- name[] doesn't support collation
      FROM pg_catalog.pg_namespace n
      JOIN pg_catalog.pg_class c       ON n.oid = c.relnamespace
      JOIN pg_catalog.pg_constraint x  ON c.oid = x.conrelid
     WHERE n.nspname = $1
       AND c.relname = $2
       AND x.contype = $3
  ORDER BY 1
$$;

alter function _keys(name, name, char) owner to supabase_admin;

grant execute on function _keys(name, name, char) to postgres with grant option;


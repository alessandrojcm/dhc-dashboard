create function has_sequence(name, name, text) returns text
    language sql
as
$$
    SELECT ok( _rexists( 'S', $1, $2 ), $3 );
$$;

alter function has_sequence(name, name, text) owner to supabase_admin;

grant execute on function has_sequence(name, name, text) to postgres with grant option;


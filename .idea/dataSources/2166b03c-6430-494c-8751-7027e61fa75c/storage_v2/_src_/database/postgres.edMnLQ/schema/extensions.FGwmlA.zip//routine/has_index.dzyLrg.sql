create function has_index(name, name, name) returns text
    language plpgsql
as
$$
BEGIN
   IF _is_schema($1) THEN
       -- ( schema, table, index )
       RETURN ok( _have_index( $1, $2, $3 ), 'Index ' || quote_ident($3) || ' should exist' );
   ELSE
       -- ( table, index, column/expression )
       RETURN has_index( $1, $2, $3, 'Index ' || quote_ident($2) || ' should exist' );
   END IF;
END;
$$;

alter function has_index(name, name, name) owner to supabase_admin;

grant execute on function has_index(name, name, name) to postgres with grant option;


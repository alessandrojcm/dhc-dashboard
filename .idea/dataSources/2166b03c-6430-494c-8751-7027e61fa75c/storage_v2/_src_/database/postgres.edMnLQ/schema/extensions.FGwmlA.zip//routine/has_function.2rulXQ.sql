create function has_function(name, text) returns text
    language sql
as
$$
    SELECT ok( _got_func($1), $2 );
$$;

alter function has_function(name, text) owner to supabase_admin;

grant execute on function has_function(name, text) to postgres with grant option;


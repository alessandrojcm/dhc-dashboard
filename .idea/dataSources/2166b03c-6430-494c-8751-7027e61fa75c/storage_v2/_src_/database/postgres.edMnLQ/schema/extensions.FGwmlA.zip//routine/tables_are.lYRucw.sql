create function tables_are(name[], text) returns text
    language sql
as
$$
    SELECT _are( 'tables', _extras('{r,p}'::char[], $1), _missing('{r,p}'::char[], $1), $2);
$$;

alter function tables_are(name[], text) owner to supabase_admin;

grant execute on function tables_are(name[], text) to postgres with grant option;


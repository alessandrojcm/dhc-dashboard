create function hasnt_column(name, name) returns text
    language sql
as
$$
    SELECT hasnt_column( $1, $2, 'Column ' || quote_ident($1) || '.' || quote_ident($2) || ' should not exist' );
$$;

alter function hasnt_column(name, name) owner to supabase_admin;

grant execute on function hasnt_column(name, name) to postgres with grant option;


create function has_any_role(user_id uuid, required_roles role_type[]) returns boolean
    security definer
    language plpgsql
as
$$
begin
    return exists (select 1
                   from user_profiles
                   where user_profiles.id = user_id
                     and (
                       roles && required_roles
                           or 'admin'::role_type = any (roles)
                           or 'president'::role_type = any (roles)
                       ));
end;
$$;

alter function has_any_role(uuid, role_type[]) owner to postgres;

grant execute on function has_any_role(uuid, role_type[]) to anon;

grant execute on function has_any_role(uuid, role_type[]) to authenticated;

grant execute on function has_any_role(uuid, role_type[]) to service_role;


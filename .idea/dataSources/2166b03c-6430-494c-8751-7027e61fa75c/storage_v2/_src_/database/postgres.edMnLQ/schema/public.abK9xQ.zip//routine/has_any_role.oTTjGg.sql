create function has_any_role(uid uuid, required_roles role_type[]) returns trigger
    SET search_path = ""
    language plpgsql
as
$$
begin
    new.updated_at = now();
    return new;
end;
$$;

alter function has_any_role(uuid, role_type[]) owner to postgres;

grant execute on function has_any_role(uuid, role_type[]) to anon;

grant execute on function has_any_role(uuid, role_type[]) to authenticated;

grant execute on function has_any_role(uuid, role_type[]) to service_role;


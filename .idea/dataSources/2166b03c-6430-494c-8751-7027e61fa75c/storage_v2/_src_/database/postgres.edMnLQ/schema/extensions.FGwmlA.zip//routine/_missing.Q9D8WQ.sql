create function _missing(character[], name, name[]) returns name[]
    language sql
as
$$
    SELECT ARRAY(
        SELECT $3[i]
          FROM generate_series(1, array_upper($3, 1)) s(i)
        EXCEPT
        SELECT c.relname
          FROM pg_catalog.pg_namespace n
          JOIN pg_catalog.pg_class c ON n.oid = c.relnamespace
         WHERE c.relkind = ANY($1)
           AND n.nspname = $2
    );
$$;

alter function _missing(character[], name, name[]) owner to supabase_admin;

grant execute on function _missing(character[], name, name[]) to postgres with grant option;


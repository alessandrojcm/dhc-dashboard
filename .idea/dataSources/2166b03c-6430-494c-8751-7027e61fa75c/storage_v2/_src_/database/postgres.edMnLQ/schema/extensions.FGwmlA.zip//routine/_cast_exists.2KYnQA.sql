create function _cast_exists(name, name, name, name) returns boolean
    language sql
as
$$
    SELECT EXISTS (
       SELECT TRUE
         FROM pg_catalog.pg_cast c
         JOIN pg_catalog.pg_proc p ON c.castfunc = p.oid
         JOIN pg_catalog.pg_namespace n ON p.pronamespace = n.oid
        WHERE _cmp_types(castsource, $1)
          AND _cmp_types(casttarget, $2)
          AND n.nspname   = $3
          AND p.proname   = $4
   );
$$;

alter function _cast_exists(name, name, name, name) owner to supabase_admin;

grant execute on function _cast_exists(name, name, name, name) to postgres with grant option;


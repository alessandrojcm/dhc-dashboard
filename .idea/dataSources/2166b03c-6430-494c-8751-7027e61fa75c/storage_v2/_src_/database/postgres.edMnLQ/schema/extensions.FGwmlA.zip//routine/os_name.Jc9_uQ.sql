create function os_name() returns text
    immutable
    language sql
as
$$SELECT 'linux'::text;$$;

alter function os_name() owner to supabase_admin;

grant execute on function os_name() to postgres with grant option;


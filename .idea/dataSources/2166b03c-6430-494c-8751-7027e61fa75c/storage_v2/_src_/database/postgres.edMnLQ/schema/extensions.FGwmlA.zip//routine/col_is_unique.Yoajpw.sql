create function col_is_unique(name, name) returns text
    language sql
as
$$
    SELECT col_is_unique( $1, $2, 'Column ' || quote_ident($1) || '(' || quote_ident($2) || ') should have a unique constraint' );
$$;

alter function col_is_unique(name, name) owner to supabase_admin;

grant execute on function col_is_unique(name, name) to postgres with grant option;


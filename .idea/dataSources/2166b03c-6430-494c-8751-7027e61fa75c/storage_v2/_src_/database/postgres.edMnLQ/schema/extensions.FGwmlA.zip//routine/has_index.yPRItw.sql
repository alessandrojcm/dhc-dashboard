create function has_index(name, name) returns text
    language sql
as
$$
    SELECT ok( _have_index( $1, $2 ), 'Index ' || quote_ident($2) || ' should exist' );
$$;

alter function has_index(name, name) owner to supabase_admin;

grant execute on function has_index(name, name) to postgres with grant option;


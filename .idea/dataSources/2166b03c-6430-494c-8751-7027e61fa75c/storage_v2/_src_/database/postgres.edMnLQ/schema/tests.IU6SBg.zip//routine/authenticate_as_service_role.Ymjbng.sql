create function authenticate_as_service_role() returns void
    language plpgsql
as
$$
        BEGIN
            perform set_config('role', 'service_role', true);
            perform set_config('request.jwt.claims', null, true);
        END
    $$;

alter function authenticate_as_service_role() owner to postgres;

grant execute on function authenticate_as_service_role() to anon;

grant execute on function authenticate_as_service_role() to authenticated;

grant execute on function authenticate_as_service_role() to service_role;


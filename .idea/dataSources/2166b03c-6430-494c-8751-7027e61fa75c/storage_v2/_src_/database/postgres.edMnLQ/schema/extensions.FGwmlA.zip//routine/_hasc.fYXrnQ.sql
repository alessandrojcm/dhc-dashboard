create function _hasc(name, name, character) returns boolean
    language sql
as
$$
    SELECT EXISTS(
            SELECT true
              FROM pg_catalog.pg_namespace n
              JOIN pg_catalog.pg_class c      ON c.relnamespace = n.oid
              JOIN pg_catalog.pg_constraint x ON c.oid = x.conrelid
             WHERE n.nspname = $1
               AND c.relname = $2
               AND x.contype = $3
    );
$$;

alter function _hasc(name, name, char) owner to supabase_admin;

grant execute on function _hasc(name, name, char) to postgres with grant option;


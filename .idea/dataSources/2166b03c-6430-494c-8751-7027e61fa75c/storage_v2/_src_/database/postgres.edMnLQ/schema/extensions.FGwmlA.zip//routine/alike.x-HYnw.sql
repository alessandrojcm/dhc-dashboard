create function alike(anyelement, text, text) returns text
    language sql
as
$$
    SELECT _alike( $1 ~~ $2, $1, $2, $3 );
$$;

alter function alike(anyelement, text, text) owner to supabase_admin;

grant execute on function alike(anyelement, text, text) to postgres with grant option;


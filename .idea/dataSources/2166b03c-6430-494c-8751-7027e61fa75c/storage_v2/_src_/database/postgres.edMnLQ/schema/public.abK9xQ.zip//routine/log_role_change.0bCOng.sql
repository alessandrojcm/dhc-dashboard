create function log_role_change(uid uuid, required_roles role_type[]) returns trigger
    SET search_path = ""
    language plpgsql
as
$$
begin
    if old.roles is distinct from new.roles then
        insert into user_audit_log (user_id, action, details)
        values (new.id,
                'role_update',
                jsonb_build_object(
                        'old_roles', old.roles,
                        'new_roles', new.roles,
                        'modified_by', auth.uid()
                ));
    end if;
    return new;
end;
$$;

alter function log_role_change(uuid, role_type[]) owner to postgres;

grant execute on function log_role_change(uuid, role_type[]) to anon;

grant execute on function log_role_change(uuid, role_type[]) to authenticated;

grant execute on function log_role_change(uuid, role_type[]) to service_role;


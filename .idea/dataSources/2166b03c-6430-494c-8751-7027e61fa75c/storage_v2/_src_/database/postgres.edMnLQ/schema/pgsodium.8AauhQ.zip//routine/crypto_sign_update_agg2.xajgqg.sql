create function crypto_sign_update_agg2(cur_state bytea, initial_state bytea, message bytea) returns bytea
    immutable
    language sql
as
$$
 SELECT pgsodium.crypto_sign_update(
       COALESCE(cur_state, initial_state),
	   message)
$$;

comment on function crypto_sign_update_agg2(bytea, bytea, bytea) is 'Internal helper function for crypto_sign_update_agg(bytea, bytea). This
initializes state to the state passed to the aggregate as a parameter,
if it has not already been initialized.';

alter function crypto_sign_update_agg2(bytea, bytea, bytea) owner to supabase_admin;

grant execute on function crypto_sign_update_agg2(bytea, bytea, bytea) to pgsodium_keyholder;


create function col_is_null(table_name name, column_name name, description text DEFAULT NULL::text) returns text
    language sql
as
$$
    SELECT _col_is_null( $1, $2, $3, false );
$$;

alter function col_is_null(name, name, text) owner to supabase_admin;

grant execute on function col_is_null(name, name, text) to postgres with grant option;


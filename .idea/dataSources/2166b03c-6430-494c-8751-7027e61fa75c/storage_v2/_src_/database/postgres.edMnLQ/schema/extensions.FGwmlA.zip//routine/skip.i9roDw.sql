create function skip(text) returns text
    language sql
as
$$
    SELECT ok( TRUE ) || ' ' || diag( 'SKIP' || COALESCE(' ' || $1, '') );
$$;

alter function skip(text) owner to supabase_admin;

grant execute on function skip(text) to postgres with grant option;


create function has_mask(role regrole, source_name text) returns boolean
    language sql
as
$$
  SELECT EXISTS(
    SELECT 1
      FROM pg_shseclabel
     WHERE  objoid = role
       AND provider = 'pgsodium'
       AND label ilike 'ACCESS%' || source_name || '%')
  $$;

alter function has_mask(regrole, text) owner to supabase_admin;


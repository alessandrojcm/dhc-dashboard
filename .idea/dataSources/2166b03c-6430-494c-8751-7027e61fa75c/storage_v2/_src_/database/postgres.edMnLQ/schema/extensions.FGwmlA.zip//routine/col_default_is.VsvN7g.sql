create function col_default_is(name, name, anyelement) returns text
    language sql
as
$$
    SELECT _cdi( $1, $2, $3 );
$$;

alter function col_default_is(name, name, anyelement) owner to supabase_admin;

grant execute on function col_default_is(name, name, anyelement) to postgres with grant option;


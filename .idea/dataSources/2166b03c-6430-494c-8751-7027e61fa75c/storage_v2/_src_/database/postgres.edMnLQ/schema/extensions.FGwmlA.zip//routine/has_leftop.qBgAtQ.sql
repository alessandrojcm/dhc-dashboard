create function has_leftop(name, name, name, name) returns text
    language sql
as
$$
    SELECT ok(
         _op_exists(NULL, $1, $2, $3, $4 ),
        'Left operator ' || quote_ident($1) || '.' || $2 || '(NONE,'
        || $3 || ') RETURNS ' || $4 || ' should exist'
    );
$$;

alter function has_leftop(name, name, name, name) owner to supabase_admin;

grant execute on function has_leftop(name, name, name, name) to postgres with grant option;


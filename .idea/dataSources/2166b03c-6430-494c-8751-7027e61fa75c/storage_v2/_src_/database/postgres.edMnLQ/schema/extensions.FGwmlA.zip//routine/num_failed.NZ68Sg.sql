create function num_failed() returns integer
    strict
    language sql
as
$$
    SELECT _get('failed');
$$;

alter function num_failed() owner to supabase_admin;

grant execute on function num_failed() to postgres with grant option;


create function trigger_is(name, name, name) returns text
    language sql
as
$$
    SELECT trigger_is(
        $1, $2, $3,
        'Trigger ' || quote_ident($2) || ' should call ' || quote_ident($3) || '()'
    );
$$;

alter function trigger_is(name, name, name) owner to supabase_admin;

grant execute on function trigger_is(name, name, name) to postgres with grant option;


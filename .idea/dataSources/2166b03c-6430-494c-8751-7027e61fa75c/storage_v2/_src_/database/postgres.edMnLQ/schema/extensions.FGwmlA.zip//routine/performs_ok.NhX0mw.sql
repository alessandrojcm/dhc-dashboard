create function performs_ok(text, numeric) returns text
    language sql
as
$$
    SELECT performs_ok(
        $1, $2, 'Should run in less than ' || $2 || ' ms'
    );
$$;

alter function performs_ok(text, numeric) owner to supabase_admin;

grant execute on function performs_ok(text, numeric) to postgres with grant option;


create function clear_authentication() returns void
    language plpgsql
as
$$
BEGIN
    perform set_config('role', 'anon', true);
    perform set_config('request.jwt.claims', null, true);
END
$$;

alter function clear_authentication() owner to postgres;

grant execute on function clear_authentication() to anon;

grant execute on function clear_authentication() to authenticated;

grant execute on function clear_authentication() to service_role;


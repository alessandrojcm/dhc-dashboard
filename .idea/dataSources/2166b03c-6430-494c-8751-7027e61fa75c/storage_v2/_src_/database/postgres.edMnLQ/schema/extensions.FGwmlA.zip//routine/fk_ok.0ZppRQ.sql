create function fk_ok(name, name, name, name) returns text
    language sql
as
$$
    SELECT fk_ok( $1, ARRAY[$2], $3, ARRAY[$4] );
$$;

alter function fk_ok(name, name, name, name) owner to supabase_admin;

grant execute on function fk_ok(name, name, name, name) to postgres with grant option;


create function unialike(anyelement, text) returns text
    language sql
as
$$
    SELECT _unalike( $1 !~~* $2, $1, $2, NULL );
$$;

alter function unialike(anyelement, text) owner to supabase_admin;

grant execute on function unialike(anyelement, text) to postgres with grant option;


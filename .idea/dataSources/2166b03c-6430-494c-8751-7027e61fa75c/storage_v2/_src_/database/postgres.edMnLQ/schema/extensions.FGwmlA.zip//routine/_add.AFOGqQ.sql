create function _add(text, integer) returns integer
    language sql
as
$$
    SELECT _add($1, $2, '')
$$;

alter function _add(text, integer) owner to supabase_admin;

grant execute on function _add(text, integer) to postgres with grant option;


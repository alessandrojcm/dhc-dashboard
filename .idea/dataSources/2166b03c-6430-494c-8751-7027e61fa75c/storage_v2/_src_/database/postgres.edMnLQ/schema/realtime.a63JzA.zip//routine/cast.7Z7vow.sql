create function "cast"(val text, type_ regtype) returns jsonb
    immutable
    language plpgsql
as
$$
    declare
      res jsonb;
    begin
      execute format('select to_jsonb(%L::'|| type_::text || ')', val)  into res;
      return res;
    end
    $$;

alter function "cast"(text, regtype) owner to supabase_admin;

grant execute on function "cast"(text, regtype) to postgres;

grant execute on function "cast"(text, regtype) to anon;

grant execute on function "cast"(text, regtype) to authenticated;

grant execute on function "cast"(text, regtype) to service_role;

grant execute on function "cast"(text, regtype) to dashboard_user;

grant execute on function "cast"(text, regtype) to supabase_realtime_admin;


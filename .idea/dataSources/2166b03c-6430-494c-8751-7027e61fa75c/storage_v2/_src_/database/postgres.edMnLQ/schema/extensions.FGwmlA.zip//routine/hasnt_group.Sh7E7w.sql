create function hasnt_group(name) returns text
    language sql
as
$$
    SELECT ok( NOT _has_group($1), 'Group ' || quote_ident($1) || ' should not exist' );
$$;

alter function hasnt_group(name) owner to supabase_admin;

grant execute on function hasnt_group(name) to postgres with grant option;


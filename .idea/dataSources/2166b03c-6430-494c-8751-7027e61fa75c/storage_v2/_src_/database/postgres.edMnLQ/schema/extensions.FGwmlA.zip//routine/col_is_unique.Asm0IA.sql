create function col_is_unique(name, name, name[], text) returns text
    language sql
as
$$
    SELECT _constraint( $1, $2, 'u', $3, $4, 'unique' );
$$;

alter function col_is_unique(name, name, name[], text) owner to supabase_admin;

grant execute on function col_is_unique(name, name, name[], text) to postgres with grant option;


create function _get_pg_partman_schema() returns text
    language sql
as
$$
  SELECT
    extnamespace::regnamespace::text
  FROM
    pg_extension
  WHERE
    extname = 'pg_partman';
$$;

alter function _get_pg_partman_schema() owner to postgres;


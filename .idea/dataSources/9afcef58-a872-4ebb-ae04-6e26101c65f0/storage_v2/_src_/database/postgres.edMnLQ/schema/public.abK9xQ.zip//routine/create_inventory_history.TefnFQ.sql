create function create_inventory_history() returns trigger
    security definer
    SET search_path = ""
    language plpgsql
as
$$
BEGIN
    -- Handle INSERT (creation)
    IF TG_OP = 'INSERT' THEN
        INSERT INTO public.inventory_history (
            item_id, 
            action, 
            new_container_id, 
            changed_by,
            notes
        ) VALUES (
            NEW.id,
            'created',
            NEW.container_id,
            NEW.created_by,
            'Item created'
        );
        RETURN NEW;
    END IF;
    
    -- Handle UPDATE
    IF TG_OP = 'UPDATE' THEN
        -- Check if container changed (moved)
        IF OLD.container_id != NEW.container_id THEN
            INSERT INTO public.inventory_history (
                item_id,
                action,
                old_container_id,
                new_container_id,
                changed_by,
                notes
            ) VALUES (
                NEW.id,
                'moved',
                OLD.container_id,
                NEW.container_id,
                NEW.updated_by,
                'Item moved between containers'
            );
        END IF;
        
        -- Check if maintenance status changed
        IF OLD.out_for_maintenance != NEW.out_for_maintenance THEN
            INSERT INTO public.inventory_history (
                item_id,
                action,
                new_container_id,
                changed_by,
                notes
            ) VALUES (
                NEW.id,
                CASE WHEN NEW.out_for_maintenance THEN 'maintenance_out' ELSE 'maintenance_in' END,
                NEW.container_id,
                NEW.updated_by,
                CASE WHEN NEW.out_for_maintenance THEN 'Item sent for maintenance' ELSE 'Item returned from maintenance' END
            );
        END IF;
        
        -- Check if other attributes changed
        IF OLD.attributes != NEW.attributes OR OLD.quantity != NEW.quantity OR OLD.notes != NEW.notes THEN
            INSERT INTO public.inventory_history (
                item_id,
                action,
                new_container_id,
                changed_by,
                notes
            ) VALUES (
                NEW.id,
                'updated',
                NEW.container_id,
                NEW.updated_by,
                'Item details updated'
            );
        END IF;
        
        RETURN NEW;
    END IF;
    
    RETURN NULL;
END;
$$;

alter function create_inventory_history() owner to postgres;

grant execute on function create_inventory_history() to anon;

grant execute on function create_inventory_history() to authenticated;

grant execute on function create_inventory_history() to service_role;


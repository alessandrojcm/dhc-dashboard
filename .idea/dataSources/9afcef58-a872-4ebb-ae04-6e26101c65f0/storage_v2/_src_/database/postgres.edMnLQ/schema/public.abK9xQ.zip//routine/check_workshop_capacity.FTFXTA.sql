create function check_workshop_capacity(activity_id uuid) returns boolean
    security definer
    language plpgsql
as
$$
DECLARE
    current_registrations INTEGER;
    capacity              INTEGER;
BEGIN
    -- Get current confirmed registrations
    SELECT COUNT(*)
    INTO current_registrations
    FROM club_activity_registrations
    WHERE club_activity_id = activity_id
      AND status IN ('confirmed', 'pending');

    -- Get workshop capacity
    SELECT max_capacity
    INTO capacity
    FROM club_activities
    WHERE id = activity_id;

    RETURN current_registrations < capacity;
END;
$$;

alter function check_workshop_capacity(uuid) owner to postgres;

grant execute on function check_workshop_capacity(uuid) to anon;

grant execute on function check_workshop_capacity(uuid) to authenticated;

grant execute on function check_workshop_capacity(uuid) to service_role;


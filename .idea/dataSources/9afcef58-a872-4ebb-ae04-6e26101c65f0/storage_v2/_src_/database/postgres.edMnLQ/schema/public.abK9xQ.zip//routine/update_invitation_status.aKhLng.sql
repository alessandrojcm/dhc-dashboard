create function update_invitation_status(p_invitation_id uuid, p_status invitation_status) returns boolean
    SET search_path = ""
    language plpgsql
as
$$
DECLARE
  v_status public.invitation_status;
  v_expires_at TIMESTAMPTZ;
BEGIN
  -- Check if caller has admin role, is the user associated with the invitation, or is a service role
  IF NOT (
    public.has_any_role((select auth.uid()), ARRAY['admin', 'president', 'committee_coordinator']::public.role_type[]) OR
    EXISTS (
      SELECT 1 FROM public.invitations 
      WHERE id = p_invitation_id AND user_id = (select auth.uid())
    ) OR
    (select current_role) IN ('postgres', 'service_role')
  ) THEN
    RAISE EXCEPTION USING
      errcode = 'PERM1',
      message = 'Permission denied: Cannot update invitation status';
  END IF;
  
  -- Get current status with row lock (prevents race conditions)
  SELECT status, expires_at INTO v_status, v_expires_at
  FROM public.invitations
  WHERE id = p_invitation_id
  FOR UPDATE;
  
  -- If no invitation found
  IF v_status IS NULL THEN
    RAISE EXCEPTION USING
      errcode = 'U0011',
      message = 'Invitation not found',
      hint = 'Check invitation ID and try again';
  END IF;
  
  -- Check if invitation has expired
  IF v_expires_at < now() AND v_status = 'pending' THEN
    -- Auto-update to expired
    UPDATE public.invitations
    SET status = 'expired',
        updated_at = now()
    WHERE id = p_invitation_id;
    
    RAISE EXCEPTION USING
      errcode = 'U0009',
      message = 'Invitation has expired',
      hint = 'Please request a new invitation';
  END IF;
  
  -- Ensure valid status transition
  IF (v_status = 'accepted' AND p_status != 'accepted') OR
     (v_status = 'expired' AND p_status != 'expired') OR
     (v_status = 'revoked' AND p_status != 'revoked') THEN
    RAISE EXCEPTION USING
      errcode = 'U0010',
      message = format('Invalid status transition from %s to %s', v_status, p_status),
      hint = 'Cannot change from final status';
  END IF;
  
  -- Update invitation
  UPDATE public.invitations
  SET status = p_status,
      updated_at = now()
  WHERE id = p_invitation_id;
  
  RETURN FOUND;
END;
$$;

alter function update_invitation_status(uuid, invitation_status) owner to postgres;

grant execute on function update_invitation_status(uuid, invitation_status) to anon;

grant execute on function update_invitation_status(uuid, invitation_status) to authenticated;

grant execute on function update_invitation_status(uuid, invitation_status) to service_role;


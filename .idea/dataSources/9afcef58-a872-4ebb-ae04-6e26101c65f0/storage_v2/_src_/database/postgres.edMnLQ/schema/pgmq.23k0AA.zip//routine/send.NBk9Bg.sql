create function send(queue_name text, msg jsonb, delay integer DEFAULT 0) returns SETOF bigint
    language plpgsql
as
$$
DECLARE
    sql TEXT;
    qtable TEXT := pgmq.format_table_name(queue_name, 'q');
BEGIN
    sql := FORMAT(
        $QUERY$
        INSERT INTO pgmq.%I (vt, message)
        VALUES ((clock_timestamp() + %L), $1)
        RETURNING msg_id;
        $QUERY$,
        qtable, make_interval(secs => delay)
    );
    RETURN QUERY EXECUTE sql USING msg;
END;
$$;

alter function send(text, jsonb, integer) owner to postgres;


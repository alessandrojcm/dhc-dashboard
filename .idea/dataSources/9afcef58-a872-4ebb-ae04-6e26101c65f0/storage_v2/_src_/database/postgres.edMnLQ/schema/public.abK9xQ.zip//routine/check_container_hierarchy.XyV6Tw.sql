create function check_container_hierarchy() returns trigger
    security definer
    SET search_path = ""
    language plpgsql
as
$$
DECLARE
    current_id UUID;
    visited_ids UUID[];
BEGIN
    -- If no parent, no circular reference possible
    IF NEW.parent_container_id IS NULL THEN
        RETURN NEW;
    END IF;
    
    -- Start from the parent and traverse up the hierarchy
    current_id := NEW.parent_container_id;
    visited_ids := ARRAY[NEW.id];
    
    WHILE current_id IS NOT NULL LOOP
        -- If we encounter the current container ID, we have a circular reference
        IF current_id = NEW.id THEN
            RAISE EXCEPTION 'Circular reference detected in container hierarchy';
        END IF;
        
        -- If we've already visited this ID, we have a circular reference
        IF current_id = ANY(visited_ids) THEN
            RAISE EXCEPTION 'Circular reference detected in container hierarchy';
        END IF;
        
        -- Add current ID to visited list
        visited_ids := array_append(visited_ids, current_id);
        
        -- Move to the next parent
        SELECT parent_container_id INTO current_id 
        FROM public.containers 
        WHERE id = current_id;
    END LOOP;
    
    RETURN NEW;
END;
$$;

alter function check_container_hierarchy() owner to postgres;

grant execute on function check_container_hierarchy() to anon;

grant execute on function check_container_hierarchy() to authenticated;

grant execute on function check_container_hierarchy() to service_role;


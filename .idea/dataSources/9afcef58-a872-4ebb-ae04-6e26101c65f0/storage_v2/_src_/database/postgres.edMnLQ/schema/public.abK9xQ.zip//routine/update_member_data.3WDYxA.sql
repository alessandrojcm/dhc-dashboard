create function update_member_data(user_uuid uuid, p_first_name text DEFAULT NULL::text, p_last_name text DEFAULT NULL::text, p_is_active boolean DEFAULT NULL::boolean, p_medical_conditions text DEFAULT NULL::text, p_phone_number text DEFAULT NULL::text, p_gender gender DEFAULT NULL::gender, p_pronouns text DEFAULT NULL::text, p_date_of_birth date DEFAULT NULL::date, p_next_of_kin_name text DEFAULT NULL::text, p_next_of_kin_phone text DEFAULT NULL::text, p_preferred_weapon preferred_weapon[] DEFAULT NULL::preferred_weapon[], p_membership_start_date timestamp with time zone DEFAULT NULL::timestamp with time zone, p_membership_end_date timestamp with time zone DEFAULT NULL::timestamp with time zone, p_last_payment_date timestamp with time zone DEFAULT NULL::timestamp with time zone, p_insurance_form_submitted boolean DEFAULT NULL::boolean, p_additional_data jsonb DEFAULT NULL::jsonb, p_social_media_consent social_media_consent DEFAULT 'no'::social_media_consent) returns member_data_type
    SET search_path = ""
    language plpgsql
as
$$
DECLARE v_user_profile_id UUID;
result public.member_data_type;
BEGIN -- First get the user_profile_id
SELECT id INTO v_user_profile_id
FROM public.user_profiles
WHERE supabase_user_id = user_uuid;
-- Check if user exists
IF v_user_profile_id IS NULL THEN RAISE EXCEPTION 'User with UUID % not found',
user_uuid;
END IF;
-- Update user_profiles table
UPDATE public.user_profiles
SET first_name = COALESCE(p_first_name, first_name),
    last_name = COALESCE(p_last_name, last_name),
    is_active = COALESCE(p_is_active, is_active),
    medical_conditions = COALESCE(p_medical_conditions, medical_conditions),
    phone_number = COALESCE(p_phone_number, phone_number),
    gender = COALESCE(p_gender, gender),
    pronouns = COALESCE(p_pronouns, pronouns),
    date_of_birth = COALESCE(p_date_of_birth, date_of_birth),
    social_media_consent = COALESCE(p_social_media_consent, social_media_consent),
    updated_at = NOW()
WHERE id = v_user_profile_id;
-- Update member_profiles table
UPDATE public.member_profiles
SET next_of_kin_name = COALESCE(p_next_of_kin_name, next_of_kin_name),
    next_of_kin_phone = COALESCE(p_next_of_kin_phone, next_of_kin_phone),
    preferred_weapon = COALESCE(p_preferred_weapon, preferred_weapon),
    membership_start_date = COALESCE(p_membership_start_date, membership_start_date),
    membership_end_date = COALESCE(p_membership_end_date, membership_end_date),
    last_payment_date = COALESCE(p_last_payment_date, last_payment_date),
    insurance_form_submitted = COALESCE(
        p_insurance_form_submitted,
        insurance_form_submitted
    ),
    additional_data = COALESCE(p_additional_data, additional_data),
    updated_at = NOW()
WHERE user_profile_id = v_user_profile_id;
-- Return the updated data using the existing get_member_data function
SELECT * INTO result
FROM public.get_member_data(user_uuid);
RETURN result;
EXCEPTION
WHEN OTHERS THEN RAISE;
END;
$$;

alter function update_member_data(uuid, text, text, boolean, text, text, gender, text, date, text, text, preferred_weapon[], timestamp with time zone, timestamp with time zone, timestamp with time zone, boolean, jsonb, social_media_consent) owner to postgres;

grant execute on function update_member_data(uuid, text, text, boolean, text, text, gender, text, date, text, text, preferred_weapon[], timestamp with time zone, timestamp with time zone, timestamp with time zone, boolean, jsonb, social_media_consent) to anon;

grant execute on function update_member_data(uuid, text, text, boolean, text, text, gender, text, date, text, text, preferred_weapon[], timestamp with time zone, timestamp with time zone, timestamp with time zone, boolean, jsonb, social_media_consent) to authenticated;

grant execute on function update_member_data(uuid, text, text, boolean, text, text, gender, text, date, text, text, preferred_weapon[], timestamp with time zone, timestamp with time zone, timestamp with time zone, boolean, jsonb, social_media_consent) to service_role;


create function complete_member_registration(v_user_id uuid, p_next_of_kin_name text, p_next_of_kin_phone text, p_insurance_form_submitted boolean) returns uuid
    security definer
    SET search_path = ""
    language plpgsql
as
$$
DECLARE
    p_user_profile_id UUID;
    v_member_id UUID;
BEGIN

    SELECT id into p_user_profile_id
    FROM public.user_profiles
    WHERE supabase_user_id = v_user_id;

    if p_user_profile_id is null then
        RAISE EXCEPTION 'User not found';
    end if;

    IF p_insurance_form_submitted IS FALSE THEN
        RAISE EXCEPTION 'You must submit the insurance form';
    END IF;

    -- Create member profile
    INSERT INTO public.member_profiles (id,
                                        user_profile_id,
                                        next_of_kin_name,
                                        next_of_kin_phone,
                                        preferred_weapon,
                                        insurance_form_submitted
                                        )
    VALUES (v_user_id,
            p_user_profile_id,
            p_next_of_kin_name,
            p_next_of_kin_phone,
            ARRAY []::public.preferred_weapon[],
            p_insurance_form_submitted)
    RETURNING id INTO v_member_id;

    UPDATE public.user_profiles
    SET is_active = true
    WHERE id = p_user_profile_id;

    -- Add member role
    INSERT INTO public.user_roles (user_id, role)
    VALUES (v_user_id, 'member'::public.role_type);

    RETURN v_member_id;
END;
$$;

alter function complete_member_registration(uuid, text, text, boolean) owner to postgres;

grant execute on function complete_member_registration(uuid, text, text, boolean) to anon;

grant execute on function complete_member_registration(uuid, text, text, boolean) to authenticated;

grant execute on function complete_member_registration(uuid, text, text, boolean) to service_role;


create function detach_archive(queue_name text) returns void
    language plpgsql
as
$$
DECLARE
  atable TEXT := pgmq.format_table_name(queue_name, 'a');
BEGIN
  EXECUTE format('ALTER EXTENSION pgmq DROP TABLE pgmq.%I', atable);
END
$$;

alter function detach_archive(text) owner to postgres;


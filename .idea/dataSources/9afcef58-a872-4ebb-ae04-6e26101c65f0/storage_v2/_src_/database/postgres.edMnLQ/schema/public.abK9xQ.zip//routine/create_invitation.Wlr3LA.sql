create function create_invitation(v_user_id uuid, p_email text, p_first_name text, p_last_name text, p_date_of_birth timestamp with time zone, p_phone_number text, p_invitation_type text, p_waitlist_id uuid DEFAULT NULL::uuid, p_expires_at timestamp with time zone DEFAULT (now() + '7 days'::interval), p_metadata jsonb DEFAULT NULL::jsonb) returns uuid
    SET search_path = ""
    language plpgsql
as
$$
DECLARE
  v_invitation_id UUID;
  v_existing_invitation UUID;
BEGIN
  -- Check if caller has admin role or is a service role
  IF NOT (
    public.has_any_role((select auth.uid()), ARRAY['admin', 'president', 'committee_coordinator']::public.role_type[]) OR
    (select current_role) IN ('postgres', 'service_role')
  ) THEN
    RAISE EXCEPTION USING
      errcode = 'PERM1',
      message = 'Permission denied: Admin role required to create invitations';
  END IF;

  -- Check if user already has a pending invitation
  SELECT id INTO v_existing_invitation
  FROM public.invitations
  WHERE user_id = v_user_id AND status = 'pending';
  
  IF v_existing_invitation IS NOT NULL THEN
    -- Update existing invitation instead of creating a new one
    UPDATE public.invitations
    SET status = 'pending',
        expires_at = p_expires_at,
        updated_at = now(),
        metadata = COALESCE(p_metadata, metadata)
    WHERE id = v_existing_invitation
    RETURNING id INTO v_invitation_id;
    
    -- Log the update
    RAISE NOTICE 'Updated existing invitation % for user %', v_invitation_id, v_user_id;
  ELSE
    -- Check if there's already an active invitation with same email
    UPDATE public.invitations
    SET status = 'expired',
        updated_at = now()
    WHERE email = p_email AND status = 'pending';
    
    -- Create user profile if it doesn't exist
    INSERT INTO public.user_profiles (
      supabase_user_id,
      first_name,
      last_name,
      date_of_birth,
      phone_number,
      is_active
    ) VALUES (
      v_user_id,
      p_first_name,
      p_last_name,
      p_date_of_birth,
      p_phone_number,
      false
    )
    ON CONFLICT (supabase_user_id) 
    DO UPDATE SET
      first_name = p_first_name,
      last_name = p_last_name,
      date_of_birth = p_date_of_birth,
      phone_number = p_phone_number;
    
    -- Create new invitation
    INSERT INTO public.invitations (
      email,
      user_id,
      waitlist_id,
      status,
      expires_at,
      created_by,
      invitation_type,
      metadata
    ) VALUES (
      p_email,
      v_user_id,
      p_waitlist_id,
      'pending',
      p_expires_at,
      (select auth.uid()),
      p_invitation_type,
      p_metadata
    )
    RETURNING id INTO v_invitation_id;
  END IF;
  
  RETURN v_invitation_id;
END;
$$;

alter function create_invitation(uuid, text, text, text, timestamp with time zone, text, text, uuid, timestamp with time zone, jsonb) owner to postgres;

grant execute on function create_invitation(uuid, text, text, text, timestamp with time zone, text, text, uuid, timestamp with time zone, jsonb) to anon;

grant execute on function create_invitation(uuid, text, text, text, timestamp with time zone, text, text, uuid, timestamp with time zone, jsonb) to authenticated;

grant execute on function create_invitation(uuid, text, text, text, timestamp with time zone, text, text, uuid, timestamp with time zone, jsonb) to service_role;


create function check_refund_eligibility(registration_id uuid) returns boolean
    security definer
    language plpgsql
as
$$
DECLARE
    reg_status registration_status;
    workshop_status club_activity_status;
    workshop_start_date TIMESTAMPTZ;
    workshop_refund_days INTEGER;
    refund_deadline TIMESTAMPTZ;
BEGIN
    -- Get registration and workshop details
    SELECT car.status, ca.status, ca.start_date, ca.refund_days
    INTO reg_status, workshop_status, workshop_start_date, workshop_refund_days
    FROM club_activity_registrations car
    JOIN club_activities ca ON car.club_activity_id = ca.id
    WHERE car.id = registration_id;
    
    -- Check if registration exists
    IF NOT FOUND THEN
        RETURN FALSE;
    END IF;
    
    -- Check if already refunded
    IF EXISTS (SELECT 1 FROM club_activity_refunds WHERE registration_id = registration_id) THEN
        RETURN FALSE;
    END IF;
    
    -- Check if registration is confirmed/paid
    IF reg_status NOT IN ('confirmed', 'pending') THEN
        RETURN FALSE;
    END IF;
    
    -- Check workshop status
    IF workshop_status IN ('finished', 'cancelled') THEN
        RETURN FALSE;
    END IF;
    
    -- Check refund deadline if set
    IF workshop_refund_days IS NOT NULL THEN
        refund_deadline := workshop_start_date - (workshop_refund_days || ' days')::INTERVAL;
        IF NOW() > refund_deadline THEN
            RETURN FALSE;
        END IF;
    END IF;
    
    RETURN TRUE;
END;
$$;

alter function check_refund_eligibility(uuid) owner to postgres;

grant execute on function check_refund_eligibility(uuid) to anon;

grant execute on function check_refund_eligibility(uuid) to authenticated;

grant execute on function check_refund_eligibility(uuid) to service_role;


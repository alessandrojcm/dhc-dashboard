create function get_email_from_auth_users(user_id uuid)
    returns TABLE(email character varying)
    security definer
    SET search_path = ""
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    SELECT au.email::varchar(255)
    FROM auth.users au
    WHERE au.id = user_id;
END;
$$;

alter function get_email_from_auth_users(uuid) owner to postgres;

grant execute on function get_email_from_auth_users(uuid) to anon;

grant execute on function get_email_from_auth_users(uuid) to authenticated;

grant execute on function get_email_from_auth_users(uuid) to service_role;


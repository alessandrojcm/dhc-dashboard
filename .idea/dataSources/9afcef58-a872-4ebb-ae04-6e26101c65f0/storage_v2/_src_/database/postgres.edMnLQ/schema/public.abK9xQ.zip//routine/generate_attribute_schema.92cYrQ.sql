create function generate_attribute_schema(attributes_array jsonb) returns jsonb
    language plpgsql
as
$$
DECLARE
  schema jsonb := '{"type": "object", "properties": {}, "additionalProperties": false}'::jsonb;
  required_fields text[] := '{}';
  attr jsonb;
  attr_name text;
  attr_type text;
  property_schema jsonb;
BEGIN
  -- Handle null or empty input
  IF attributes_array IS NULL OR jsonb_array_length(attributes_array) = 0 THEN
    RETURN schema;
  END IF;

  FOR attr IN SELECT jsonb_array_elements(attributes_array)
  LOOP
    -- Extract attribute name and type safely
    attr_name := attr->>'name';
    attr_type := attr->>'type';
    
    -- Skip if name is null or empty
    IF attr_name IS NULL OR attr_name = '' THEN
      CONTINUE;
    END IF;
    
    -- Build property schema based on type
    IF attr_type = 'select' AND attr->'options' IS NOT NULL THEN
      property_schema := jsonb_build_object('type', 'string', 'enum', attr->'options');
    ELSE
      property_schema := jsonb_build_object('type', 'string');
    END IF;
    
    -- Add property to schema using concat instead of jsonb_set for better null handling
    schema := schema || jsonb_build_object('properties', 
      COALESCE(schema->'properties', '{}'::jsonb) || jsonb_build_object(attr_name, property_schema)
    );
    
    -- Add to required array if needed
    IF COALESCE((attr->>'required')::boolean, false) THEN
      required_fields := array_append(required_fields, attr_name);
    END IF;
  END LOOP;
  
  -- Set required fields if any exist
  IF array_length(required_fields, 1) > 0 THEN
    schema := schema || jsonb_build_object('required', to_jsonb(required_fields));
  END IF;
  
  RETURN schema;
END;
$$;

alter function generate_attribute_schema(jsonb) owner to postgres;

grant execute on function generate_attribute_schema(jsonb) to anon;

grant execute on function generate_attribute_schema(jsonb) to authenticated;

grant execute on function generate_attribute_schema(jsonb) to service_role;


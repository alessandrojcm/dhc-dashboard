create function get_member_data(user_uuid uuid) returns member_data_type
    SET search_path = ""
    language plpgsql
as
$$
DECLARE result public.member_data_type;
BEGIN -- Get all the required data in one query
SELECT up.first_name,
    up.last_name,
    up.is_active,
    up.medical_conditions,
    up.phone_number,
    up.gender,
    up.pronouns,
    up.date_of_birth,
    mp.next_of_kin_name,
    mp.next_of_kin_phone,
    mp.preferred_weapon,
    mp.membership_start_date,
    mp.membership_end_date,
    mp.last_payment_date,
    mp.insurance_form_submitted,
    mp.additional_data,
    up.social_media_consent INTO result
FROM public.user_profiles up
    JOIN public.member_profiles mp ON mp.user_profile_id = up.id
WHERE up.supabase_user_id = user_uuid;
-- Check if user was found
IF result.first_name IS NULL THEN RAISE EXCEPTION 'User with UUID % not found',
user_uuid;
END IF;
RETURN result;
EXCEPTION
WHEN OTHERS THEN RAISE;
END;
$$;

alter function get_member_data(uuid) owner to postgres;

grant execute on function get_member_data(uuid) to anon;

grant execute on function get_member_data(uuid) to authenticated;

grant execute on function get_member_data(uuid) to service_role;


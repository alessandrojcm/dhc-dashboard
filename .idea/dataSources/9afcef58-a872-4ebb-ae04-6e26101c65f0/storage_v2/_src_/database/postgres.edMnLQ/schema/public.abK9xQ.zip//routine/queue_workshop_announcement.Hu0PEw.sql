create function queue_workshop_announcement(workshop_id uuid, announcement_type text DEFAULT 'created'::text) returns void
    security definer
    SET search_path = ""
    language plpgsql
as
$$
BEGIN
    -- Add workshop to announcement queue with metadata
    PERFORM pgmq.send(
        'workshop_announcement',
        jsonb_build_object(
            'workshop_id', workshop_id,
            'announcement_type', announcement_type,
            'queued_at', NOW()
        )
    );
END;
$$;

alter function queue_workshop_announcement(uuid, text) owner to postgres;

grant execute on function queue_workshop_announcement(uuid, text) to anon;

grant execute on function queue_workshop_announcement(uuid, text) to authenticated;

grant execute on function queue_workshop_announcement(uuid, text) to service_role;


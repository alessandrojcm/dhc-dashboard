create function "create"(queue_name text) returns void
    language plpgsql
as
$$
BEGIN
    PERFORM pgmq.create_non_partitioned(queue_name);
END;
$$;

alter function "create"(text) owner to postgres;


create function get_weapons_options() returns json
    SET search_path = ""
    language plpgsql
as
$$
DECLARE
    options json;
begin
    select json_agg(enumlabel) as weapon_options
    into options
    from pg_enum
    where enumtypid = 'public.preferred_weapon'::regtype;
    return options;
end;
$$;

alter function get_weapons_options() owner to postgres;

grant execute on function get_weapons_options() to anon;

grant execute on function get_weapons_options() to authenticated;

grant execute on function get_weapons_options() to service_role;


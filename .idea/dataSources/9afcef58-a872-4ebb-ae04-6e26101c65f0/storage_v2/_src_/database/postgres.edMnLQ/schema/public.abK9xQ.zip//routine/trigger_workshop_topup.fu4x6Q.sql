create function trigger_workshop_topup() returns text
    security definer
    SET search_path = ""
    language plpgsql
as
$$
DECLARE
    v_response TEXT;
BEGIN
    -- Call the workshop_topup edge function via HTTP
    select net.http_post(
                   url := (select decrypted_secret from vault.decrypted_secrets where name = 'project_url') ||
                          '/functions/v1/workshop_topup',
                   headers := jsonb_build_object(
                           'Content-type', 'application/json',
                           'Authorization', 'Bearer ' || (select decrypted_secret
                                                          from vault.decrypted_secrets
                                                          where name = 'service_role_key')
                              ),
                   body := concat('{"time": "', now(), '"}')::jsonb
           )
    into v_response;

    RETURN 'Workshop topup scheduled: ' || COALESCE(v_response, 'No response');
EXCEPTION
    WHEN OTHERS THEN
        RETURN 'Error triggering workshop topup: ' || SQLERRM;
END;
$$;

alter function trigger_workshop_topup() owner to postgres;

grant execute on function trigger_workshop_topup() to anon;

grant execute on function trigger_workshop_topup() to authenticated;

grant execute on function trigger_workshop_topup() to service_role;


create function list_queues() returns SETOF pgmq.queue_record
    language plpgsql
as
$$
BEGIN
  RETURN QUERY SELECT * FROM pgmq.meta;
END
$$;

alter function list_queues() owner to postgres;


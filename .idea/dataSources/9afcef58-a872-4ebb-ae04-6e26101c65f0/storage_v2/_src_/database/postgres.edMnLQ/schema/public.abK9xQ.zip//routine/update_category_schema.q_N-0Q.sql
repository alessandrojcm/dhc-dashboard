create function update_category_schema() returns trigger
    language plpgsql
as
$$
BEGIN
  NEW.attribute_schema := generate_attribute_schema(NEW.available_attributes);
  RETURN NEW;
END;
$$;

alter function update_category_schema() owner to postgres;

grant execute on function update_category_schema() to anon;

grant execute on function update_category_schema() to authenticated;

grant execute on function update_category_schema() to service_role;


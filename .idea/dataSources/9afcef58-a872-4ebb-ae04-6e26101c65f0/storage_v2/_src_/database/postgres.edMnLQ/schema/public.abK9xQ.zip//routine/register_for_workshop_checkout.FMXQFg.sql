create function register_for_workshop_checkout(p_activity_id uuid, p_amount_paid integer, p_stripe_checkout_session_id text, p_member_user_id uuid DEFAULT NULL::uuid, p_external_user_data jsonb DEFAULT NULL::jsonb) returns uuid
    security definer
    SET search_path = ""
    language plpgsql
as
$$
DECLARE
    registration_id  UUID;
    external_user_id UUID;
BEGIN
    -- Check capacity
    IF NOT public.check_workshop_capacity(p_activity_id) THEN
        RAISE EXCEPTION 'Workshop is at full capacity';
    END IF;

    -- Handle external user creation if needed
    IF p_external_user_data IS NOT NULL THEN
        INSERT INTO public.external_users (first_name, last_name, email, phone_number)
        VALUES (p_external_user_data ->> 'first_name',
                p_external_user_data ->> 'last_name',
                p_external_user_data ->> 'email',
                p_external_user_data ->> 'phone_number')
        ON CONFLICT (email) DO UPDATE SET first_name   = EXCLUDED.first_name,
                                          last_name    = EXCLUDED.last_name,
                                          phone_number = EXCLUDED.phone_number,
                                          updated_at   = NOW()
        RETURNING id INTO external_user_id;
    END IF;

    -- Create registration
    INSERT INTO public.club_activity_registrations (club_activity_id,
                                                    member_user_id,
                                                    external_user_id,
                                                    amount_paid,
                                                    stripe_checkout_session_id,
                                                    status)
    VALUES (p_activity_id,
            p_member_user_id,
            external_user_id,
            p_amount_paid,
            p_stripe_checkout_session_id,
            'pending')
    RETURNING id INTO registration_id;

    RETURN registration_id;
END;
$$;

alter function register_for_workshop_checkout(uuid, integer, text, uuid, jsonb) owner to postgres;

grant execute on function register_for_workshop_checkout(uuid, integer, text, uuid, jsonb) to anon;

grant execute on function register_for_workshop_checkout(uuid, integer, text, uuid, jsonb) to authenticated;

grant execute on function register_for_workshop_checkout(uuid, integer, text, uuid, jsonb) to service_role;


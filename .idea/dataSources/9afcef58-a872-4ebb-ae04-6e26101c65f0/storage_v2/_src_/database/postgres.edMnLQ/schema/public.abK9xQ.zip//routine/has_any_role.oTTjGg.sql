create function has_any_role(uid uuid, required_roles role_type[]) returns boolean
    security definer
    SET search_path = ""
    language plpgsql
as
$$ begin return exists (
        select 1
        from public.user_roles
        where user_roles.user_id = uid
            and (
                select role = any (required_roles)
            )
    );
end;
$$;

alter function has_any_role(uuid, role_type[]) owner to postgres;

grant execute on function has_any_role(uuid, role_type[]) to anon;

grant execute on function has_any_role(uuid, role_type[]) to authenticated;

grant execute on function has_any_role(uuid, role_type[]) to service_role;


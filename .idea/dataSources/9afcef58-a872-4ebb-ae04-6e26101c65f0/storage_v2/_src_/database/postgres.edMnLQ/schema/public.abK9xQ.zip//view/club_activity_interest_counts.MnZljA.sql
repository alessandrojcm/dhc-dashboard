create view club_activity_interest_counts(club_activity_id, interest_count) as
SELECT club_activity_interest.club_activity_id,
       count(*) AS interest_count
FROM club_activity_interest
GROUP BY club_activity_interest.club_activity_id;

alter table club_activity_interest_counts
    owner to postgres;

grant delete, insert, references, select, trigger, truncate, update on club_activity_interest_counts to anon;

grant delete, insert, references, select, trigger, truncate, update on club_activity_interest_counts to authenticated;

grant delete, insert, references, select, trigger, truncate, update on club_activity_interest_counts to service_role;


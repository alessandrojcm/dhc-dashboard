create view member_management_view
            (id, user_profile_id, next_of_kin_name, next_of_kin_phone, preferred_weapon, membership_start_date,
             membership_end_date, last_payment_date, insurance_form_submitted, additional_data, created_at, updated_at,
             subscription_paused_until, first_name, last_name, phone_number, gender, pronouns, is_active, customer_id,
             medical_conditions, email, from_waitlist_id, waitlist_registration_date, roles, age, search_text,
             social_media_consent, guardian_first_name, guardian_last_name, guardian_phone_number)
as
SELECT mp.id,
       mp.user_profile_id,
       mp.next_of_kin_name,
       mp.next_of_kin_phone,
       mp.preferred_weapon,
       mp.membership_start_date,
       mp.membership_end_date,
       mp.last_payment_date,
       mp.insurance_form_submitted,
       mp.additional_data,
       mp.created_at,
       mp.updated_at,
       mp.subscription_paused_until,
       up.first_name,
       up.last_name,
       up.phone_number,
       up.gender,
       up.pronouns,
       up.is_active,
       up.customer_id,
       up.medical_conditions,
       (SELECT get_email_from_auth_users.email
        FROM get_email_from_auth_users(up.supabase_user_id) get_email_from_auth_users(email)) AS email,
       w.id                                                                                   AS from_waitlist_id,
       w.initial_registration_date                                                            AS waitlist_registration_date,
       array_agg(ur.role)                                                                     AS roles,
       EXTRACT(year FROM age(up.date_of_birth::timestamp with time zone))                     AS age,
       up.search_text,
       up.social_media_consent,
       wg.first_name                                                                          AS guardian_first_name,
       wg.last_name                                                                           AS guardian_last_name,
       wg.phone_number                                                                        AS guardian_phone_number
FROM member_profiles mp
         JOIN user_profiles up ON mp.user_profile_id = up.id
         LEFT JOIN waitlist w ON up.waitlist_id = w.id
         LEFT JOIN user_roles ur ON up.supabase_user_id = ur.user_id
         LEFT JOIN waitlist_guardians wg ON wg.profile_id = up.id
GROUP BY mp.id, up.id, w.id, wg.id;

alter table member_management_view
    owner to postgres;

grant delete, insert, references, select, trigger, truncate, update on member_management_view to anon;

grant delete, insert, references, select, trigger, truncate, update on member_management_view to authenticated;

grant delete, insert, references, select, trigger, truncate, update on member_management_view to service_role;


create function trigger_workshop_announcement() returns trigger
    security definer
    language plpgsql
as
$$
DECLARE
    announcement_type TEXT;
    should_announce BOOLEAN := false;
BEGIN
    -- Determine announcement type and if we should announce
    IF TG_OP = 'INSERT' THEN
        announcement_type := 'created';
        should_announce := NEW.announce_discord OR NEW.announce_email;
    ELSIF TG_OP = 'UPDATE' THEN
        -- Only announce for specific changes
        IF OLD.status != NEW.status THEN
            announcement_type := 'status_changed';
            should_announce := NEW.announce_discord OR NEW.announce_email;
        ELSIF OLD.start_date != NEW.start_date OR OLD.end_date != NEW.end_date THEN
            announcement_type := 'time_changed';
            should_announce := NEW.announce_discord OR NEW.announce_email;
        ELSIF OLD.location != NEW.location THEN
            announcement_type := 'location_changed';
            should_announce := NEW.announce_discord OR NEW.announce_email;
        END IF;
    END IF;

    -- Queue announcement if needed
    IF should_announce THEN
        PERFORM queue_workshop_announcement(NEW.id, announcement_type);
    END IF;

    RETURN COALESCE(NEW, OLD);
END;
$$;

alter function trigger_workshop_announcement() owner to postgres;

grant execute on function trigger_workshop_announcement() to anon;

grant execute on function trigger_workshop_announcement() to authenticated;

grant execute on function trigger_workshop_announcement() to service_role;


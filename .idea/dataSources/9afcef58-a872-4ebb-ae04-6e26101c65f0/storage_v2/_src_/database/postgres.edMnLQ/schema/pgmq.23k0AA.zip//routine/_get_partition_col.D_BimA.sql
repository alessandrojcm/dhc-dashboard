create function _get_partition_col(partition_interval text) returns text
    language plpgsql
as
$$
DECLARE
  num INTEGER;
BEGIN
    BEGIN
        num := partition_interval::INTEGER;
        RETURN 'msg_id';
    EXCEPTION
        WHEN others THEN
            RETURN 'enqueued_at';
    END;
END;
$$;

alter function _get_partition_col(text) owner to postgres;


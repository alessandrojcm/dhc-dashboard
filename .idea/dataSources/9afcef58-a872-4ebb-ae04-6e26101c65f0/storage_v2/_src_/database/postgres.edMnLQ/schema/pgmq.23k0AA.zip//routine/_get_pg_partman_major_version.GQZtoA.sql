create function _get_pg_partman_major_version() returns integer
    language sql
as
$$
  SELECT split_part(extversion, '.', 1)::INT
  FROM pg_extension
  WHERE extname = 'pg_partman'
$$;

alter function _get_pg_partman_major_version() owner to postgres;


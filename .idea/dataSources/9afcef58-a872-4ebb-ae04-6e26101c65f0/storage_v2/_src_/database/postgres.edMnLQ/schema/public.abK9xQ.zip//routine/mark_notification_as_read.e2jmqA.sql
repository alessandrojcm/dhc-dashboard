create function mark_notification_as_read(notification_id uuid) returns void
    security definer
    language plpgsql
as
$$
BEGIN
  UPDATE public.notifications
  SET read_at = now()
  WHERE id = notification_id AND user_id = (SELECT auth.uid());
END;
$$;

alter function mark_notification_as_read(uuid) owner to postgres;

grant execute on function mark_notification_as_read(uuid) to anon;

grant execute on function mark_notification_as_read(uuid) to authenticated;

grant execute on function mark_notification_as_read(uuid) to service_role;


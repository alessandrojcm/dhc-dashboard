create function validate_queue_name(queue_name text) returns void
    language plpgsql
as
$$
BEGIN
  IF length(queue_name) >= 48 THEN
    RAISE EXCEPTION 'queue name is too long, maximum length is 48 characters';
  END IF;
END;
$$;

alter function validate_queue_name(text) owner to postgres;


create function metrics_all() returns SETOF pgmq.metrics_result
    language plpgsql
as
$$
DECLARE
    row_name RECORD;
    result_row pgmq.metrics_result;
BEGIN
    FOR row_name IN SELECT queue_name FROM pgmq.meta LOOP
        result_row := pgmq.metrics(row_name.queue_name);
        RETURN NEXT result_row;
    END LOOP;
END;
$$;

alter function metrics_all() owner to postgres;


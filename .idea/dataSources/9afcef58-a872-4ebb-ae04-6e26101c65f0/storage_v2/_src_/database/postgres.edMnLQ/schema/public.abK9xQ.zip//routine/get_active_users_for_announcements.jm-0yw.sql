create function get_active_users_for_announcements()
    returns TABLE(user_id uuid, email text, first_name text, last_name text)
    security definer
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    SELECT 
        up.supabase_user_id,
        au.email,
        up.first_name,
        up.last_name
    FROM user_profiles up
    LEFT JOIN auth.users au ON up.supabase_user_id = au.id
    WHERE up.is_active = true
    AND au.email IS NOT NULL;
END;
$$;

alter function get_active_users_for_announcements() owner to postgres;

grant execute on function get_active_users_for_announcements() to anon;

grant execute on function get_active_users_for_announcements() to authenticated;

grant execute on function get_active_users_for_announcements() to service_role;


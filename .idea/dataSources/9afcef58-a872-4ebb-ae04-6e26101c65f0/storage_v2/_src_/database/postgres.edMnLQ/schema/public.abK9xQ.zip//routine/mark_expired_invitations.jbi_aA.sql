create function mark_expired_invitations() returns integer
    security definer
    SET search_path = ""
    language plpgsql
as
$$
DECLARE
  v_count INTEGER;
BEGIN
  -- Update invitations that have expired
  UPDATE public.invitations
  SET status = 'expired',
      updated_at = now()
  WHERE status = 'pending'
    AND expires_at < now();
  
  -- Get the count of updated invitations
  GET DIAGNOSTICS v_count = ROW_COUNT;
  
  -- Log the update to a table or return the count
  RETURN v_count;
END;
$$;

alter function mark_expired_invitations() owner to postgres;

grant execute on function mark_expired_invitations() to anon;

grant execute on function mark_expired_invitations() to authenticated;

grant execute on function mark_expired_invitations() to service_role;


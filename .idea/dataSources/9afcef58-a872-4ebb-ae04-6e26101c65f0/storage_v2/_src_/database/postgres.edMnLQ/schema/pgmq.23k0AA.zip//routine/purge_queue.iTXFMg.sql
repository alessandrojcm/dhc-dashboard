create function purge_queue(queue_name text) returns bigint
    language plpgsql
as
$$
DECLARE
  deleted_count INTEGER;
  qtable TEXT := pgmq.format_table_name(queue_name, 'q');
BEGIN
  EXECUTE format('DELETE FROM pgmq.%I', qtable);
  GET DIAGNOSTICS deleted_count = ROW_COUNT;
  RETURN deleted_count;
END
$$;

alter function purge_queue(text) owner to postgres;


create function custom_access_token_hook(event jsonb) returns jsonb
    SET search_path = ""
    language plpgsql
as
$$
declare claims jsonb;
user_roles public.role_type [];
is_valid bool;
begin -- Check if user_id exists in the event
if event->>'user_id' is null then raise log 'Invalid token data: missing user_id';
return jsonb_build_object(
    'error',
    jsonb_build_object(
        'http_code',
        403,
        'message',
        'Invalid token data'
    )
);
end if;
-- Check if user exists in user_profiles
select exists(
        select 1
        from public.user_profiles
        where supabase_user_id = (event->>'user_id')::uuid
    ) into is_valid;
raise log 'Checking user profile existence: %',
jsonb_build_object(
    'user_id',
    event->>'user_id',
    'exists',
    is_valid
);
if not is_valid then raise warning 'User not found in profiles: %',
event->>'user_id';
return jsonb_build_object(
    'error',
    jsonb_build_object(
        'http_code',
        403,
        'message',
        'User not registered in the system'
    )
);
end if;
-- Get user roles
begin
select array_agg(role) into user_roles
from public.user_roles
where user_id = (event->>'user_id')::uuid;
raise log 'User roles fetched: %',
jsonb_build_object(
    'user_id',
    event->>'user_id',
    'roles',
    user_roles
);
exception
when others then raise warning 'Error fetching user roles: %',
SQLERRM;
return jsonb_build_object(
    'error',
    jsonb_build_object(
        'http_code',
        403,
        'message',
        'Error fetching user roles'
    )
);
end;
-- Handle claims
begin claims := event->'claims';
if claims is null then claims := '{}'::jsonb;
end if;
-- Ensure app_metadata exists
if not claims ? 'app_metadata' then claims := jsonb_set(claims, '{app_metadata}', '{}'::jsonb);
end if;
-- Add roles to claims
claims := jsonb_set(
    claims,
    '{app_metadata,roles}',
    coalesce(to_jsonb(user_roles), '[]'::jsonb)
);
-- Update final event
event := jsonb_set(event, '{claims}', claims);
raise log 'Claims updated successfully: %',
jsonb_build_object(
    'user_id',
    event->>'user_id',
    'final_claims',
    claims
);
return event;
exception
when others then raise warning 'Error processing claims: %',
SQLERRM;
return jsonb_build_object(
    'error',
    jsonb_build_object(
        'http_code',
        403,
        'message',
        'Error processing claims'
    )
);
end;
end;
$$;

alter function custom_access_token_hook(jsonb) owner to postgres;

grant execute on function custom_access_token_hook(jsonb) to anon;

grant execute on function custom_access_token_hook(jsonb) to authenticated;

grant execute on function custom_access_token_hook(jsonb) to service_role;


create view decrypted_secrets
            (id, name, description, secret, decrypted_secret, key_id, nonce, created_at, updated_at) as
SELECT s.id,
       s.name,
       s.description,
       s.secret,
       convert_from(vault._crypto_aead_det_decrypt(message => decode(s.secret, 'base64'::text),
                                                   additional => convert_to(s.id::text, 'utf8'::name),
                                                   key_id => 0::bigint, context => '\x7067736f6469756d'::bytea,
                                                   nonce => s.nonce), 'utf8'::name) AS decrypted_secret,
       s.key_id,
       s.nonce,
       s.created_at,
       s.updated_at
FROM vault.secrets s;

alter table decrypted_secrets
    owner to supabase_admin;

grant delete, select on decrypted_secrets to postgres with grant option;


create function update_member_payment(p_user_id uuid, p_payment_date timestamp with time zone DEFAULT now()) returns void
    security definer
    SET search_path = ""
    language plpgsql
as
$$
BEGIN
    -- Update member profile payment date
    UPDATE public.member_profiles
    SET last_payment_date = p_payment_date
    WHERE id = p_user_id;

    -- Update user_profiles active status
    UPDATE public.user_profiles
    SET is_active = true
    WHERE supabase_user_id = p_user_id;
END;
$$;

alter function update_member_payment(uuid, timestamp with time zone) owner to postgres;

grant execute on function update_member_payment(uuid, timestamp with time zone) to anon;

grant execute on function update_member_payment(uuid, timestamp with time zone) to authenticated;

grant execute on function update_member_payment(uuid, timestamp with time zone) to service_role;


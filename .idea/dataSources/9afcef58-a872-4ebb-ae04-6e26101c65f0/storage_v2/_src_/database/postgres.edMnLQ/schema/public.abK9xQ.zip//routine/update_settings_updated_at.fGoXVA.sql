create function update_settings_updated_at() returns trigger
    language plpgsql
as
$$ BEGIN NEW.updated_at = now();
NEW.updated_by = auth.uid();
RETURN NEW;
END;
$$;

alter function update_settings_updated_at() owner to postgres;

grant execute on function update_settings_updated_at() to anon;

grant execute on function update_settings_updated_at() to authenticated;

grant execute on function update_settings_updated_at() to service_role;


create function cleanup_payment_sessions() returns integer
    security definer
    SET search_path = ""
    language plpgsql
as
$$
DECLARE
  v_count INTEGER;
BEGIN
  -- Delete expired and unused payment sessions
  DELETE FROM public.payment_sessions
  WHERE (expires_at < now() AND is_used = false) OR
        (created_at < now() - INTERVAL '30 days');
  
  -- Get the count of deleted payment sessions
  GET DIAGNOSTICS v_count = ROW_COUNT;
  
  -- Return the count of deleted sessions
  RETURN v_count;
END;
$$;

alter function cleanup_payment_sessions() owner to postgres;

grant execute on function cleanup_payment_sessions() to anon;

grant execute on function cleanup_payment_sessions() to authenticated;

grant execute on function cleanup_payment_sessions() to service_role;


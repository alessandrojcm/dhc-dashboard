create function validate_item_attributes() returns trigger
    security definer
    SET search_path = ""
    language plpgsql
as
$$
DECLARE
    category_schema JSONB;
BEGIN
    -- Get the attribute schema for this category
    SELECT attribute_schema INTO category_schema
    FROM public.equipment_categories
    WHERE id = NEW.category_id;
    
    -- If no schema defined, allow any attributes
    IF category_schema IS NULL OR category_schema = '{}' THEN
        RETURN NEW;
    END IF;
    
    -- Validate attributes against schema using pg-jsonschema
    IF NOT extensions.jsonb_matches_schema(category_schema::json, NEW.attributes) THEN
        RAISE EXCEPTION 'Item attributes do not match category schema. Schema: %, Attributes: %', 
            category_schema, NEW.attributes;
    END IF;
    
    RETURN NEW;
END;
$$;

alter function validate_item_attributes() owner to postgres;

grant execute on function validate_item_attributes() to anon;

grant execute on function validate_item_attributes() to authenticated;

grant execute on function validate_item_attributes() to service_role;


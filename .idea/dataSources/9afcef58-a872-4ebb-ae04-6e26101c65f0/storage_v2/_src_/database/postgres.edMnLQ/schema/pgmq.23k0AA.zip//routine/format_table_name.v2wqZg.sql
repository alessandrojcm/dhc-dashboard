create function format_table_name(queue_name text, prefix text) returns text
    language plpgsql
as
$$
BEGIN
    IF queue_name ~ '\$|;|--|'''
    THEN
        RAISE EXCEPTION 'queue name contains invalid characters: $, ;, --, or \''';
    END IF;
    RETURN lower(prefix || '_' || queue_name);
END;
$$;

alter function format_table_name(text, text) owner to postgres;


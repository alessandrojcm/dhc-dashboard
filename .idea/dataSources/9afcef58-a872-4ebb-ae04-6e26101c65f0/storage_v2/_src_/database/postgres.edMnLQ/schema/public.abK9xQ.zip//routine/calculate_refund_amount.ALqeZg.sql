create function calculate_refund_amount(registration_id uuid) returns integer
    security definer
    SET search_path = ""
    language plpgsql
as
$$
DECLARE
    amount_paid INTEGER;
BEGIN
    SELECT car.amount_paid
    INTO amount_paid
    FROM public.club_activity_registrations car
    WHERE car.id = registration_id;

    -- For now, full refund if eligible
    -- Future: could implement partial refunds based on timing
    RETURN COALESCE(amount_paid, 0);
END;
$$;

alter function calculate_refund_amount(uuid) owner to postgres;

grant execute on function calculate_refund_amount(uuid) to anon;

grant execute on function calculate_refund_amount(uuid) to authenticated;

grant execute on function calculate_refund_amount(uuid) to service_role;


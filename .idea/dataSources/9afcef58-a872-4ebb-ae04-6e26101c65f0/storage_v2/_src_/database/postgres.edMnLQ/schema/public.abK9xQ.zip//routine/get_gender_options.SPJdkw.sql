create function get_gender_options() returns json
    SET search_path = ""
    language plpgsql
as
$$
DECLARE
    options json;
begin
    select json_agg(enumlabel) as gender_options
    into options
    from pg_enum
    where enumtypid = 'public.gender'::regtype;
    return options;
end;
$$;

alter function get_gender_options() owner to postgres;

grant execute on function get_gender_options() to anon;

grant execute on function get_gender_options() to authenticated;

grant execute on function get_gender_options() to service_role;

